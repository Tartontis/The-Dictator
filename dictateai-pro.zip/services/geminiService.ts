
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Refines raw transcription into a high-quality research prompt or structured text.
 */
export const refineTranscription = async (text: string, mode: 'prompt' | 'summary' | 'deep_research'): Promise<string> => {
  const instructions = {
    prompt: `Transform the following user dictation into a "Premium Deep Research Prompt". 
    Structure it for an expert-level LLM (like Gemini 3 Pro). 
    Include:
    1. Role: Define a world-class persona for the AI.
    2. Objective: Clearly state the primary goal.
    3. Constraints: List specific technical and stylistic requirements.
    4. Step-by-Step Instructions: Break down the logic.
    5. Output Format: Specify the desired structure (e.g., Markdown, JSON).
    Ensure the resulting prompt is sophisticated, nuanced, and uses professional terminology.`,
    
    summary: "Condense this dictation into a high-density executive brief. Use bullet points for key insights and bold text for critical action items. Maintain a professional, 'no-fluff' tone.",
    
    deep_research: "Analyze the dictation and construct a 'Research Architecture'. Identify hidden assumptions, propose 3-5 high-value investigative vectors, and list potential cross-disciplinary connections. Format as a professional research outline."
  };

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: text,
    config: {
      systemInstruction: instructions[mode],
      temperature: 0.8,
      topP: 0.9,
    },
  });

  return response.text || "Failed to refine text.";
};

/**
 * Transcribes audio data using Gemini's native audio support.
 */
export const transcribeAudio = async (base64Audio: string): Promise<string> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: 'audio/wav',
            data: base64Audio,
          },
        },
        { text: "Task: Transcription. Output only the verbatim text spoken. Correct spelling of specialized technical terms if context allows. Do not add intro/outro text." }
      ]
    },
  });

  return response.text || "";
};
