
import { useEffect, useState, useCallback } from 'react';
import { MidiAction, MidiMapping } from '../types';

export const useMidi = (mappings: MidiMapping[], onAction: (action: MidiAction) => void) => {
  const [midiStatus, setMidiStatus] = useState<'not-supported' | 'connected' | 'disconnected'>('disconnected');
  const [lastNote, setLastNote] = useState<number | null>(null);

  const handleMidiMessage = useCallback((message: any) => {
    const [status, note, velocity] = message.data;
    
    // Note On event (144) with velocity > 0
    if (status === 144 && velocity > 0) {
      setLastNote(note);
      const mapping = mappings.find(m => m.note === note);
      if (mapping) {
        onAction(mapping.action);
      }
    }
  }, [mappings, onAction]);

  useEffect(() => {
    if (!navigator.requestMIDIAccess) {
      setMidiStatus('not-supported');
      return;
    }

    navigator.requestMIDIAccess()
      .then((access) => {
        const inputs = Array.from(access.inputs.values());
        if (inputs.length > 0) {
          setMidiStatus('connected');
          inputs.forEach(input => {
            input.onmidimessage = handleMidiMessage;
          });
        }

        access.onstatechange = (e: any) => {
          const hasInputs = Array.from(access.inputs.values()).length > 0;
          setMidiStatus(hasInputs ? 'connected' : 'disconnected');
        };
      })
      .catch(() => setMidiStatus('disconnected'));
  }, [handleMidiMessage]);

  return { midiStatus, lastNote };
};
