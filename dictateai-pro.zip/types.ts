
export interface TranscriptionEntry {
  id: string;
  timestamp: number;
  rawText: string;
  refinedText?: string;
  tags: string[];
}

export enum MidiAction {
  TOGGLE_RECORD = 'TOGGLE_RECORD',
  REFINE_PROMPT = 'REFINE_PROMPT',
  COPY_CLIPBOARD = 'COPY_CLIPBOARD',
  EXPORT_MD = 'EXPORT_MD',
  CLEAR_CURRENT = 'CLEAR_CURRENT',
  SAVE_SESSION = 'SAVE_SESSION',
  LAUNCH_EXTERNAL = 'LAUNCH_EXTERNAL'
}

export interface MidiMapping {
  note: number;
  action: MidiAction;
}

export interface AppState {
  isRecording: boolean;
  currentText: string;
  history: TranscriptionEntry[];
  isProcessing: boolean;
  autoCopy: boolean;
}
