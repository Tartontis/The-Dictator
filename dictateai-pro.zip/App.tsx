
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { TranscriptionEntry, MidiAction, MidiMapping } from './types';
import { transcribeAudio, refineTranscription } from './services/geminiService';
import { useMidi } from './hooks/useMidi';

const DEFAULT_MAPPINGS: MidiMapping[] = [
  { note: 36, action: MidiAction.TOGGLE_RECORD }, 
  { note: 37, action: MidiAction.REFINE_PROMPT },  
  { note: 38, action: MidiAction.COPY_CLIPBOARD }, 
  { note: 39, action: MidiAction.EXPORT_MD },     
  { note: 40, action: MidiAction.CLEAR_CURRENT },  
  { note: 41, action: MidiAction.SAVE_SESSION },
  { note: 42, action: MidiAction.LAUNCH_EXTERNAL }
];

const EXTERNAL_LLMS = [
  { name: 'ChatGPT', url: 'https://chatgpt.com' },
  { name: 'Claude', url: 'https://claude.ai' },
  { name: 'Perplexity', url: 'https://perplexity.ai' },
  { name: 'Gemini', url: 'https://gemini.google.com/app' }
];

const App: React.FC = () => {
  const [isRecording, setIsRecording] = useState(false);
  const [currentText, setCurrentText] = useState('');
  const [history, setHistory] = useState<TranscriptionEntry[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [autoCopy, setAutoCopy] = useState(true);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem('dictator_history');
    const savedAutoCopy = localStorage.getItem('dictator_autocopy');
    if (saved) setHistory(JSON.parse(saved));
    if (savedAutoCopy !== null) setAutoCopy(JSON.parse(savedAutoCopy));
  }, []);

  useEffect(() => {
    localStorage.setItem('dictator_history', JSON.stringify(history));
    localStorage.setItem('dictator_autocopy', JSON.stringify(autoCopy));
  }, [history, autoCopy]);

  const handleCopy = useCallback((textToCopy?: string) => {
    const text = textToCopy || currentText;
    if (text) {
      navigator.clipboard.writeText(text);
    }
  }, [currentText]);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;
      chunksRef.current = [];

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };

      recorder.onstop = async () => {
        setIsProcessing(true);
        const audioBlob = new Blob(chunksRef.current, { type: 'audio/wav' });
        const reader = new FileReader();
        reader.readAsDataURL(audioBlob);
        reader.onloadend = async () => {
          const base64Audio = (reader.result as string).split(',')[1];
          try {
            const transcript = await transcribeAudio(base64Audio);
            setCurrentText(prev => {
              const newText = prev ? prev + ' ' + transcript : transcript;
              if (autoCopy) handleCopy(newText);
              return newText;
            });
          } catch (error) {
            console.error("Transcription error:", error);
          } finally {
            setIsProcessing(false);
          }
        };
        stream.getTracks().forEach(track => track.stop());
      };

      recorder.start();
      setIsRecording(true);
    } catch (err) {
      console.error("Failed to start recording:", err);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const handleToggleRecord = useCallback(() => {
    if (isRecording) stopRecording();
    else startRecording();
  }, [isRecording]);

  const handleRefine = async (mode: 'prompt' | 'summary' | 'deep_research' = 'prompt') => {
    if (!currentText) return;
    setIsProcessing(true);
    try {
      const refined = await refineTranscription(currentText, mode);
      setCurrentText(refined);
      if (autoCopy) handleCopy(refined);
    } catch (error) {
      console.error("Refinement error:", error);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSaveToHistory = () => {
    if (!currentText.trim()) return;
    const newEntry: TranscriptionEntry = {
      id: crypto.randomUUID(),
      timestamp: Date.now(),
      rawText: currentText,
      tags: []
    };
    setHistory(prev => [newEntry, ...prev]);
    setCurrentText('');
  };

  const handleExportMd = () => {
    const content = history.map(h => 
      `### ${new Date(h.timestamp).toLocaleString()}\n\n${h.rawText}\n\n---\n`
    ).join('\n');
    const blob = new Blob([content], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `the-dictator-session-${new Date().toISOString().split('T')[0]}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleLaunchLLM = (url: string) => {
    handleCopy();
    window.open(url, '_blank');
  };

  const handleMidiAction = useCallback((action: MidiAction) => {
    switch (action) {
      case MidiAction.TOGGLE_RECORD: handleToggleRecord(); break;
      case MidiAction.REFINE_PROMPT: handleRefine('prompt'); break;
      case MidiAction.COPY_CLIPBOARD: handleCopy(); break;
      case MidiAction.EXPORT_MD: handleExportMd(); break;
      case MidiAction.CLEAR_CURRENT: setCurrentText(''); break;
      case MidiAction.SAVE_SESSION: handleSaveToHistory(); break;
      case MidiAction.LAUNCH_EXTERNAL: handleLaunchLLM(EXTERNAL_LLMS[0].url); break;
    }
  }, [handleToggleRecord, currentText, history, handleCopy, autoCopy]);

  const { midiStatus, lastNote } = useMidi(DEFAULT_MAPPINGS, handleMidiAction);

  return (
    <div className="min-h-screen p-4 md:p-8 flex flex-col max-w-6xl mx-auto">
      {/* Header */}
      <header className="flex justify-between items-end mb-10">
        <div>
          <h1 className="text-4xl font-black text-white tracking-tighter uppercase italic">
            The <span className="text-blue-500 underline decoration-blue-500/30 underline-offset-8">Dictator</span>
          </h1>
          <p className="text-slate-500 text-xs mt-2 uppercase tracking-[0.2em] font-medium">Command Your Workflow</p>
        </div>
        <div className="flex flex-col items-end gap-2">
          <div className="flex gap-2">
            <div className={`px-4 py-1 rounded-full text-[10px] font-bold tracking-widest flex items-center gap-2 border ${
              midiStatus === 'connected' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' : 'bg-slate-800 text-slate-500 border-slate-700'
            }`}>
              {midiStatus === 'connected' && <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div>}
              MIDI: {midiStatus.toUpperCase()}
            </div>
            <button 
              onClick={() => setAutoCopy(!autoCopy)}
              className={`px-4 py-1 rounded-full text-[10px] font-bold tracking-widest border transition-colors ${
                autoCopy ? 'bg-blue-500/10 text-blue-400 border-blue-500/30' : 'bg-slate-800 text-slate-500 border-slate-700'
              }`}
            >
              AUTO-COPY: {autoCopy ? 'ON' : 'OFF'}
            </button>
          </div>
        </div>
      </header>

      <main className="grid grid-cols-1 lg:grid-cols-4 gap-8 flex-1">
        {/* Main Interface */}
        <div className="lg:col-span-3 space-y-6">
          <div className="relative group shadow-2xl">
            <textarea
              value={currentText}
              onChange={(e) => setCurrentText(e.target.value)}
              placeholder="Recording output will appear here..."
              className="w-full h-[500px] bg-slate-900/40 border border-slate-800 rounded-3xl p-8 text-xl text-slate-200 focus:outline-none focus:border-blue-500/50 transition-all resize-none font-light leading-relaxed tracking-wide"
            />
            {isProcessing && (
              <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-md rounded-3xl flex items-center justify-center z-10">
                <div className="flex flex-col items-center gap-6">
                  <div className="flex gap-1.5">
                    {[0, 1, 2].map(i => (
                      <div key={i} className="w-3 h-10 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: `${i * 0.1}s` }}></div>
                    ))}
                  </div>
                  <span className="text-blue-400 font-bold uppercase tracking-[0.3em] text-sm">Processing Intelligence</span>
                </div>
              </div>
            )}
            
            {/* Visualizer overlay (faux) */}
            {isRecording && (
              <div className="absolute bottom-6 right-8 flex items-center gap-1.5">
                 {[...Array(6)].map((_, i) => (
                   <div key={i} className="w-1 bg-red-500 rounded-full animate-pulse" style={{ height: `${Math.random() * 20 + 10}px`, animationDelay: `${i * 0.05}s` }}></div>
                 ))}
                 <span className="text-red-500 font-bold text-xs uppercase ml-2 tracking-widest">Live</span>
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <button
              onClick={handleToggleRecord}
              className={`col-span-2 flex items-center justify-center gap-3 py-5 px-8 rounded-2xl font-black uppercase tracking-widest transition-all ${
                isRecording 
                ? 'bg-red-500 hover:bg-red-600 text-white glow-red scale-[1.02]' 
                : 'bg-white hover:bg-slate-100 text-slate-950'
              }`}
            >
              {isRecording ? 'Terminate Sequence' : 'Commence Dictation'}
            </button>
            
            <button
              onClick={() => handleRefine('prompt')}
              disabled={!currentText || isProcessing}
              className="bg-slate-800 hover:bg-slate-700 disabled:opacity-30 border border-slate-700 text-white py-5 px-4 rounded-2xl font-bold uppercase text-xs tracking-widest transition-all"
            >
              Refine Prompt
            </button>

            <button
              onClick={() => handleRefine('deep_research')}
              disabled={!currentText || isProcessing}
              className="bg-slate-800 hover:bg-slate-700 disabled:opacity-30 border border-slate-700 text-white py-5 px-4 rounded-2xl font-bold uppercase text-xs tracking-widest transition-all"
            >
              Deep Research
            </button>
          </div>

          {/* External LLM Quick Launch */}
          <div className="pt-4 flex flex-wrap items-center gap-4 border-t border-slate-800/50">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Launch Intelligence:</span>
            {EXTERNAL_LLMS.map(llm => (
              <button
                key={llm.name}
                onClick={() => handleLaunchLLM(llm.url)}
                className="px-4 py-2 bg-slate-900/50 hover:bg-blue-500/10 hover:text-blue-400 border border-slate-800 rounded-xl text-xs font-bold text-slate-400 transition-all"
              >
                {llm.name}
              </button>
            ))}
          </div>
        </div>

        {/* Sidebar / Logs */}
        <div className="space-y-6">
          <div className="flex justify-between items-center px-1">
            <h2 className="text-sm font-black text-slate-500 uppercase tracking-[0.2em]">Transmission Log</h2>
            <button 
              onClick={handleExportMd}
              className="text-[10px] bg-slate-800 hover:bg-slate-700 border border-slate-700 px-3 py-1 rounded-lg text-slate-300 font-bold uppercase tracking-wider"
            >
              MD Export
            </button>
          </div>
          
          <div className="bg-slate-950/40 border border-slate-900 rounded-3xl h-[620px] overflow-y-auto space-y-3 p-3 shadow-inner">
            {history.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-slate-700 text-center p-8">
                <div className="w-12 h-12 border border-slate-800 rounded-2xl flex items-center justify-center mb-4 opacity-50">
                  ∅
                </div>
                <p className="text-xs font-bold uppercase tracking-widest">Vault Empty</p>
              </div>
            ) : (
              history.map(entry => (
                <div key={entry.id} className="glass rounded-2xl p-4 hover:bg-slate-800/40 transition-all group relative">
                  <div className="flex justify-between items-center mb-3">
                    <span className="text-[9px] font-black text-blue-500/60 uppercase tracking-widest">
                      {new Date(entry.timestamp).toLocaleTimeString()}
                    </span>
                    <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                       <button onClick={() => handleCopy(entry.rawText)} className="text-[10px] text-slate-400 hover:text-white">Copy</button>
                       <button onClick={() => setHistory(prev => prev.filter(p => p.id !== entry.id))} className="text-[10px] text-red-900 hover:text-red-500">Del</button>
                    </div>
                  </div>
                  <p className="text-xs text-slate-400 line-clamp-4 leading-relaxed font-medium">
                    {entry.rawText}
                  </p>
                  <button
                    onClick={() => {
                      setCurrentText(entry.rawText);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="mt-4 w-full py-2 bg-slate-800/50 hover:bg-slate-700 rounded-xl text-[10px] text-slate-300 font-bold uppercase tracking-widest"
                  >
                    Restore to Console
                  </button>
                </div>
              ))
            )}
          </div>

          <div className="glass rounded-2xl p-5 border-blue-500/10">
            <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] mb-4">Hardware Matrix</h3>
            <div className="grid grid-cols-2 gap-2">
              {DEFAULT_MAPPINGS.map(m => (
                <div key={m.note} className={`flex items-center gap-2 text-[9px] p-2 rounded-xl border transition-all ${lastNote === m.note ? 'bg-blue-500/20 border-blue-500/50 text-blue-300' : 'bg-slate-900/50 border-slate-800 text-slate-500'}`}>
                  <span className={`w-5 h-5 flex items-center justify-center rounded-lg text-[10px] font-black ${lastNote === m.note ? 'bg-blue-500 text-white' : 'bg-slate-800 text-slate-400'}`}>{m.note}</span>
                  <span className="truncate font-bold uppercase tracking-tighter">{m.action.replace('_', ' ')}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>

      <footer className="mt-12 py-8 border-t border-slate-900 flex justify-between items-center text-slate-600 text-[10px] font-bold uppercase tracking-[0.3em]">
        <span>Single-User High-Fidelity Console</span>
        <span className="flex items-center gap-2">
           <div className="w-1.5 h-1.5 rounded-full bg-blue-500"></div>
           System Nominal
        </span>
      </footer>
    </div>
  );
};

export default App;
