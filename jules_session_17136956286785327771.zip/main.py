from src.ui.main_window import DictationApp

if __name__ == "__main__":
    app = DictationApp()
    app.protocol("WM_DELETE_WINDOW", app.on_closing)
    app.mainloop()
