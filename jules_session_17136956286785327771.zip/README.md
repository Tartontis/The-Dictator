# Lightweight Dictation App

A lightweight, local dictation application designed for Linux (Chromebook/Crostini compatible).

## Features
*   **Local Transcription:** Uses `faster-whisper` for fast, private transcription.
*   **MIDI Trigger:** Supports MIDI drum pads for hands-free recording control.
*   **Clipboard Integration:** Automatically copies transcription to clipboard.
*   **Session Logging:** Saves all transcriptions to a daily Markdown file.
*   **GUI:** Modern interface built with `customtkinter`.

## Requirements
*   Python 3.10+
*   `ffmpeg` installed on the system (`sudo apt install ffmpeg`)
*   PortAudio (for sounddevice) (`sudo apt install libportaudio2`)

## Usage
1.  Install dependencies: `pip install -r requirements.txt`
2.  Run the app: `python main.py`

## Architecture
*   **Recorder:** `sounddevice` + `soundfile`
*   **Transcriber:** `faster-whisper`
*   **GUI:** `customtkinter`

## Future Plans
*   AI Integration for prompt refinement.
*   Direct browser automation.
