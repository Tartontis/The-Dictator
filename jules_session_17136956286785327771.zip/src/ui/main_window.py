import customtkinter as ctk
import threading
import pyperclip
import os
from src.audio.recorder import AudioRecorder
from src.audio.transcriber import Transcriber
from src.core.session import SessionLogger
from src.input.midi_handler import MidiHandler

ctk.set_appearance_mode("System")  # Modes: "System" (standard), "Dark", "Light"
ctk.set_default_color_theme("blue")  # Themes: "blue" (standard), "green", "dark-blue"

class DictationApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("Lightweight Dictation")
        self.geometry("700x500")

        # Initialize UI elements container
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        # Status Label
        self.status_label = ctk.CTkLabel(self, text="Initializing...", font=("Arial", 14))
        self.status_label.grid(row=0, column=0, padx=20, pady=(20, 10), sticky="ew")

        # Text Area
        self.text_area = ctk.CTkTextbox(self, font=("Arial", 16))
        self.text_area.grid(row=1, column=0, padx=20, pady=10, sticky="nsew")

        # Buttons Frame
        self.button_frame = ctk.CTkFrame(self)
        self.button_frame.grid(row=2, column=0, padx=20, pady=20, sticky="ew")
        self.button_frame.grid_columnconfigure(0, weight=1)
        self.button_frame.grid_columnconfigure(1, weight=1)

        # Record Button
        self.record_button = ctk.CTkButton(self.button_frame, text="Record", command=self.toggle_recording)
        self.record_button.grid(row=0, column=0, padx=10, pady=10, sticky="ew")

        # Copy Button
        self.copy_button = ctk.CTkButton(self.button_frame, text="Copy to Clipboard", command=self.copy_current_text)
        self.copy_button.grid(row=0, column=1, padx=10, pady=10, sticky="ew")

        # Internal State
        self.is_recording = False
        self.recorder = None
        self.transcriber = None
        self.logger = None
        self.midi = None
        
        # Initialize Backend in a separate thread to not freeze UI startup if model loading takes time
        # However, for simplicity/stability, we load model on startup but show 'Loading'
        self.status_label.configure(text="Loading Whisper Model...")
        self.update() # Force UI update
        
        try:
            self.recorder = AudioRecorder()
            self.transcriber = Transcriber(model_size="base")
            self.logger = SessionLogger()
            self.midi = MidiHandler(self.midi_callback)
            
            self.midi.start()
            self.status_label.configure(text="Ready")
        except Exception as e:
            self.status_label.configure(text=f"Initialization Error: {e}")
            print(f"Error initializing backend: {e}")

    def midi_callback(self):
        """Called from MIDI thread."""
        self.after(0, self.toggle_recording)

    def toggle_recording(self):
        """Toggles recording state."""
        if not self.is_recording:
            self.start_recording()
        else:
            self.stop_recording()

    def start_recording(self):
        self.is_recording = True
        self.record_button.configure(text="Stop Recording", fg_color="red", hover_color="darkred")
        self.status_label.configure(text="Recording...")
        self.recorder.start_recording()

    def stop_recording(self):
        self.is_recording = False
        self.record_button.configure(text="Record", fg_color=("#3B8ED0", "#1F6AA5"), hover_color=("#36719F", "#144870")) # Reset to default blue
        self.status_label.configure(text="Processing...")
        
        # Run processing in thread
        threading.Thread(target=self._process_recording).start()

    def _process_recording(self):
        audio_file = self.recorder.stop_recording()
        if audio_file:
            try:
                text = self.transcriber.transcribe(audio_file)
                self.logger.log_transcription(text)
                
                # Cleanup temp file
                try:
                    os.remove(audio_file)
                except:
                    pass

                # Update UI
                self.after(0, lambda: self._on_transcription_complete(text))
            except Exception as e:
                error_msg = str(e)
                self.after(0, lambda: self.status_label.configure(text=f"Error: {error_msg}"))

    def _on_transcription_complete(self, text):
        self.text_area.insert("end", text + "\n\n")
        self.text_area.see("end") # Scroll to bottom
        self._copy_to_clipboard(text)
        self.status_label.configure(text="Transcribed and Copied!")

    def copy_current_text(self):
        text = self.text_area.get("1.0", "end-1c")
        self._copy_to_clipboard(text)

    def _copy_to_clipboard(self, text):
        try:
            pyperclip.copy(text)
            self.status_label.configure(text="Copied to clipboard!")
        except Exception as e:
            self.status_label.configure(text=f"Clipboard Error: {e}")
            
    def on_closing(self):
        if self.midi:
            self.midi.stop()
        if self.recorder and self.is_recording:
            try:
                self.recorder.stop_recording()
            except:
                pass
        self.destroy()

if __name__ == "__main__":
    app = DictationApp()
    app.protocol("WM_DELETE_WINDOW", app.on_closing)
    app.mainloop()
