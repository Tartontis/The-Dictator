import os
from datetime import datetime

class SessionLogger:
    def __init__(self, log_dir="logs"):
        self.log_dir = log_dir
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)

    def log_transcription(self, text):
        """
        Appends the transcription to a daily markdown file.
        Returns the path to the log file.
        """
        now = datetime.now()
        date_str = now.strftime("%Y-%m-%d")
        time_str = now.strftime("%H:%M:%S")
        filename = os.path.join(self.log_dir, f"session_{date_str}.md")
        
        # Format the entry
        entry = f"\n### {time_str}\n{text}\n"
        
        try:
            with open(filename, "a", encoding="utf-8") as f:
                f.write(entry)
            print(f"Logged to {filename}")
        except Exception as e:
            print(f"Failed to log transcription: {e}")
            
        return filename
