import mido
import threading

class MidiHandler:
    def __init__(self, callback, device_name=None):
        """
        Initialize MIDI Handler.
        Args:
            callback: Function to call when a drum pad is hit.
            device_name: Substring to match for the MIDI device name.
        """
        self.callback = callback
        self.device_name = device_name
        self.running = False
        self.thread = None
        self.inport = None

    def list_devices(self):
        try:
            return mido.get_input_names()
        except Exception:
            return []

    def start(self):
        try:
            inputs = self.list_devices()
            if not inputs:
                print("No MIDI devices found. MIDI features disabled.")
                return

            # Simple auto-selection if not specified
            port_name = inputs[0]
            if self.device_name:
                found = False
                for name in inputs:
                    if self.device_name in name:
                        port_name = name
                        found = True
                        break
                if not found:
                    print(f"MIDI device '{self.device_name}' not found. Using '{port_name}'.")
            
            print(f"Opening MIDI port: {port_name}")
            self.inport = mido.open_input(port_name)
            self.running = True
            self.thread = threading.Thread(target=self._listen, daemon=True)
            self.thread.start()
        except Exception as e:
            print(f"Error starting MIDI handler: {e}")

    def _listen(self):
        """Background thread to listen for MIDI messages."""
        try:
            for msg in self.inport:
                if not self.running:
                    break
                if msg.type == 'note_on' and msg.velocity > 0:
                    print(f"MIDI Note On: {msg.note}")
                    # Trigger the callback
                    # We might want to debounce this or handle specific notes later
                    self.callback()
        except Exception as e:
            print(f"MIDI listening error: {e}")

    def stop(self):
        self.running = False
        if self.inport:
            self.inport.close()
            self.inport = None
