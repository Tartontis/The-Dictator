import sounddevice as sd
import soundfile as sf
import numpy as np
import threading
import queue
import tempfile
import os

class AudioRecorder:
    def __init__(self, sample_rate=16000, channels=1):
        self.sample_rate = sample_rate
        self.channels = channels
        self.recording = False
        self.audio_queue = queue.Queue()
        self.stream = None
        self.thread = None
        self.filename = None

    def start_recording(self):
        """Starts recording audio to a temporary file."""
        if self.recording:
            return
        self.recording = True
        # Create a temp file
        fd, self.filename = tempfile.mkstemp(suffix=".wav")
        os.close(fd) # Close the file descriptor, sf will open it by name
        
        self.audio_queue = queue.Queue()
        
        def callback(indata, frames, time, status):
            if status:
                print(f"Audio Callback Status: {status}")
            self.audio_queue.put(indata.copy())

        self.stream = sd.InputStream(samplerate=self.sample_rate, 
                                     channels=self.channels, 
                                     callback=callback)
        self.stream.start()
        
        self.thread = threading.Thread(target=self._write_file)
        self.thread.start()
        print("Recording started...")

    def _write_file(self):
        """Background thread to write audio data to file."""
        with sf.SoundFile(self.filename, mode='w', samplerate=self.sample_rate, channels=self.channels) as file:
            while self.recording or not self.audio_queue.empty():
                try:
                    data = self.audio_queue.get(timeout=0.1)
                    file.write(data)
                except queue.Empty:
                    continue

    def stop_recording(self):
        """Stops recording and returns the filename."""
        if not self.recording:
            return None
        self.recording = False
        if self.stream:
            self.stream.stop()
            self.stream.close()
        if self.thread:
            self.thread.join()
        
        print(f"Recording stopped. Saved to {self.filename}")
        return self.filename
