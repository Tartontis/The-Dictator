from faster_whisper import WhisperModel
import os

class Transcriber:
    def __init__(self, model_size="base", device="cpu", compute_type="int8"):
        """
        Initialize the Whisper model.
        Args:
            model_size: Size of the model (tiny, base, small, medium, large-v2)
            device: 'cpu' or 'cuda'
            compute_type: 'int8', 'float16', 'float32'
        """
        print(f"Loading Whisper model '{model_size}' on {device}...")
        self.model = WhisperModel(model_size, device=device, compute_type=compute_type)
        print("Model loaded.")

    def transcribe(self, audio_path):
        """
        Transcribe the audio file at the given path.
        Returns the transcribed text string.
        """
        if not os.path.exists(audio_path):
            raise FileNotFoundError(f"Audio file not found: {audio_path}")
            
        # Run transcription
        # beam_size=5 is standard for good accuracy
        segments, info = self.model.transcribe(audio_path, beam_size=5)
        
        full_text = []
        for segment in segments:
            full_text.append(segment.text)
            
        return " ".join(full_text).strip()
