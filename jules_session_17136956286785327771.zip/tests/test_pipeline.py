import unittest
import os
import shutil
from unittest.mock import MagicMock, patch
import sys

# Mock modules that might fail in headless environment or are missing
sys.modules['sounddevice'] = MagicMock()
sys.modules['soundfile'] = MagicMock()
sys.modules['customtkinter'] = MagicMock()
sys.modules['pyperclip'] = MagicMock()
sys.modules['mido'] = MagicMock()
sys.modules['python-rtmidi'] = MagicMock()
sys.modules['faster_whisper'] = MagicMock()

# Now import the modules to test
# We have to be careful not to import them before mocking if they are top-level in the test file
# But here we import from src... which imports them.
# So the mocks above should work.

from src.core.session import SessionLogger
from src.audio.transcriber import Transcriber

class TestDictationApp(unittest.TestCase):
    def setUp(self):
        self.test_log_dir = "tests/logs"
        if os.path.exists(self.test_log_dir):
            shutil.rmtree(self.test_log_dir)
        self.logger = SessionLogger(log_dir=self.test_log_dir)

    def tearDown(self):
        if os.path.exists(self.test_log_dir):
            shutil.rmtree(self.test_log_dir)

    def test_session_logger(self):
        text = "Hello, world!"
        log_file = self.logger.log_transcription(text)
        
        self.assertTrue(os.path.exists(log_file))
        with open(log_file, "r") as f:
            content = f.read()
            self.assertIn(text, content)
            self.assertIn("###", content)

    def test_transcriber(self):
        # We mocked faster_whisper in sys.modules, so we need to configure that mock
        MockModel = sys.modules['faster_whisper'].WhisperModel
        mock_instance = MockModel.return_value
        
        # Setup the mock to return segments
        MockSegment = MagicMock()
        MockSegment.text = "This is a test."
        mock_instance.transcribe.return_value = ([MockSegment], None)
        
        transcriber = Transcriber(model_size="tiny")
        
        # Create a dummy file
        with open("test_audio.wav", "w") as f:
            f.write("dummy")
            
        try:
            result = transcriber.transcribe("test_audio.wav")
            self.assertEqual(result, "This is a test.")
        finally:
            if os.path.exists("test_audio.wav"):
                os.remove("test_audio.wav")

if __name__ == '__main__':
    unittest.main()
