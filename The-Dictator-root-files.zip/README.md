# The-Dictator (voxpad)

Local-first dictation + command center triggered by a MIDI controller.

**MVP loop:** hit pad → speak → hit pad → transcription lands in your clipboard and is appended to a session `.md`.

No cloud by default. No subscription. No “please wait while we monetize your thoughts.”

---

## What it does (today)

- **MIDI-triggered recording** — map pads/buttons to actions
- **Local transcription** — `faster-whisper` (CPU-friendly; configurable)
- **Session logging** — every dictation appended to timestamped Markdown
- **Clipboard integration** — paste into any chat/app instantly
- **Extension hooks** — optional actions like prompt refinement, opening an LLM chat, etc.

---

## Architecture (simple core, optional “brain”)

**Core (local):**
- MIDI input → start/stop recording
- audio capture → normalize → transcribe
- write to session `.md`
- copy to clipboard

**Optional (hybrid):**
- extensions can send the transcript to a remote API (your cluster / chosen model)
- return “refined prompt”, structured notes, tags, etc.
- launch a browser to your chosen LLM with prefilled context

See `ARCHITECTURE.md` for the event-bus + module boundaries.

---

## Quick start

```bash
# from repo root
python -m venv .venv
source .venv/bin/activate

pip install -e ".[dev]"

# Confirm your controller is visible and discover note numbers:
python scripts/test_midi_device.py

# Run:
voxpad
```

---

## Chromebook / Crostini notes

- **Microphone:** enable Linux mic access in ChromeOS settings.
- **MIDI:** some devices pass through cleanly, some don’t. If your controller isn’t detected,
  the first debug step is `python scripts/test_midi_device.py`.

There’s also `scripts/install_chromebook.sh` to help with common dependencies.

---

## Configuration

Tracked defaults live in:
- `config/default.yaml`
- `config/midi_mappings.yaml`

User overrides should live outside the repo (recommended):
- `~/.voxpad/config/default.yaml`
- `~/.voxpad/config/midi_mappings.yaml`

---

## MIDI controller mapping (example)

Tested controller: MIDIPLUS Xpad (16 pads, 3 banks).

Typical “first bank” note range is often **36–51**, but you should confirm with:
```bash
python scripts/test_midi_device.py
```

Suggested starter mapping (fits the 4×4 grid nicely):

- **Row 1:** record / copy / clear / undo
- **Row 2:** refine / open Claude / open ChatGPT / open Perplexity
- **Row 3–4:** reserved for future macros

See `config/midi_mappings.yaml` for a complete example.

---

## Repo rules (multi-agent safe)

- **Events are the contract.** Don’t import across modules; subscribe/emit instead.
- If you add/modify actions or config schema: update the docs in the same PR.
- Keep the MVP boring. Make it work every time before it gets clever.

See `CONTRIBUTING.md`.

---

## License

MIT (see `LICENSE`).
