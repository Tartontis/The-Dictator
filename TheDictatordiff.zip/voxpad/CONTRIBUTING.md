# Contributing to VoxPad

This project is designed for **multi-agent development** — multiple AI coding agents (and humans) working on different modules simultaneously.

## Coordination Rules

### 1. Claim Your Module

Before starting work, declare which module you're working on. Modules are designed to be independent:

| Module | Scope | Dependencies |
|--------|-------|--------------|
| `voxpad/input/` | MIDI, hotkeys, audio capture | Only `events.py` |
| `voxpad/core/` | Transcription, session management | Only `events.py` |
| `voxpad/output/` | Clipboard, GUI, notifications | Only `events.py` |
| `voxpad/extend/` | Extensions | Only `events.py` + `session.py` |

### 2. Don't Cross Module Boundaries

**Wrong:**
```python
# In output/clipboard.py
from voxpad.input.midi import MidiHandler  # NO!
```

**Right:**
```python
# In output/clipboard.py
from voxpad.core.events import EventBus, EventType

class ClipboardManager:
    def __init__(self, bus: EventBus):
        bus.subscribe(EventType.TRANSCRIPTION_COMPLETE, self._on_transcription)
```

### 3. Events Are The Contract

The event types in `voxpad/core/events.py` are the API contract. If you need a new event:

1. Add it to `EventType` enum
2. Document the payload in the docstring
3. Notify other agents

### 4. Tests First

Write failing tests that define expected behavior. Your implementation makes them pass.

```python
# tests/test_clipboard.py
def test_copies_transcription_on_event():
    bus = EventBus()
    clipboard = ClipboardManager(bus)
    
    bus.emit(Event(
        type=EventType.TRANSCRIPTION_COMPLETE,
        data={"text": "Hello world"}
    ))
    
    assert get_clipboard_content() == "Hello world"
```

### 5. Config Over Code

Behavior changes should be configurable, not hardcoded:

**Wrong:**
```python
model = WhisperModel("large-v3")  # Hardcoded
```

**Right:**
```python
model = WhisperModel(config["whisper"]["model"])
```

## Development Setup

```bash
# Clone
git clone https://github.com/YOUR_USERNAME/voxpad.git
cd voxpad

# Create venv
python -m venv .venv
source .venv/bin/activate

# Install with dev dependencies
pip install -e ".[dev]"

# Run tests
pytest

# Run with debug logging
VOXPAD_DEBUG=1 voxpad
```

## Code Style

- Python 3.10+ (use `|` union types, `match` statements where appropriate)
- Type hints on all public functions
- Docstrings for classes and non-trivial functions
- `black` for formatting, `ruff` for linting

## Commit Messages

```
module: short description

Longer explanation if needed.

- Bullet points for multiple changes
- Reference issues with #123
```

Examples:
```
input/midi: add velocity-based action variants
core/transcriber: switch to batched inference for long recordings
extend/prompt_refiner: initial implementation
```

## Pull Request Process

1. One module per PR (keeps reviews focused)
2. Tests must pass
3. Update relevant docs if adding features
4. Tag other agents if your change affects the event contract

## Architecture Decisions

Major changes need discussion. Create an issue with:

- **Problem:** What's not working?
- **Proposal:** What's your solution?
- **Alternatives:** What else did you consider?
- **Impact:** Which modules are affected?

## Questions?

Open an issue tagged `question` or discuss in the PR.
