# VoxPad

Local-first voice dictation triggered by MIDI controller. Built for speed, privacy, and extensibility.

## What It Does

1. Hit a pad on your MIDI drum controller
2. Speak
3. Hit the pad again
4. Transcription appears in your clipboard (and logs to a session file)

No cloud. No latency. No subscription.

## Features

- **MIDI-triggered recording** — Map any pad/button to any action
- **Faster-Whisper transcription** — Runs locally, fast even on CPU
- **Session logging** — Every dictation saved to timestamped `.md` files
- **Clipboard integration** — Paste anywhere instantly
- **Extensible** — Hook system for AI refinement, browser automation, etc.

## Quick Start

```bash
# Clone and install
git clone https://github.com/YOUR_USERNAME/voxpad.git
cd voxpad
pip install -e ".[dev]"

# Test your MIDI device
python scripts/test_midi_device.py

# Run
voxpad
```

## Requirements

- Python 3.10+
- Faster-Whisper (auto-installs)
- For Chromebook/Crostini: Audio input must be enabled in Linux settings

## Configuration

Edit `config/default.yaml` for general settings, `config/midi_mappings.yaml` for pad assignments.

```yaml
# midi_mappings.yaml example
mappings:
  36: record_toggle      # Pad 1
  37: copy_to_clipboard  # Pad 2  
  38: clear_session      # Pad 3
```

## Architecture

See [ARCHITECTURE.md](ARCHITECTURE.md) for design decisions and module responsibilities.

## Contributing

Multiple agents/developers can work on this simultaneously. See [CONTRIBUTING.md](CONTRIBUTING.md) for coordination guidelines.

## Roadmap

- [x] Core dictation flow
- [ ] AI-powered prompt refinement (API extension)
- [ ] Browser launcher with context injection
- [ ] TUI with live waveform display
- [ ] Multi-model support (local LLM post-processing)

## License

MIT
