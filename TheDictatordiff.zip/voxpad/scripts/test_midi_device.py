#!/usr/bin/env python3
"""
MIDI Device Test Script

Interactive tool to discover MIDI device note numbers for configuration.

Usage:
    python scripts/test_midi_device.py
    
Press keys on your MIDI controller to see their note numbers.
Use these numbers in config/midi_mappings.yaml
"""

from __future__ import annotations

import sys
import time


def main() -> int:
    """Run interactive MIDI test."""
    try:
        import rtmidi
    except ImportError:
        print("Error: python-rtmidi not installed")
        print("Install with: pip install python-rtmidi")
        return 1
    
    midi_in = rtmidi.MidiIn()
    ports = midi_in.get_ports()
    
    if not ports:
        print("No MIDI input devices found!")
        print("\nMake sure your MIDI controller is connected.")
        return 1
    
    print("Available MIDI input devices:")
    for i, name in enumerate(ports):
        print(f"  [{i}] {name}")
    
    # Select port
    if len(ports) == 1:
        port_index = 0
        print(f"\nUsing: {ports[0]}")
    else:
        try:
            port_index = int(input("\nSelect device number: "))
            if port_index < 0 or port_index >= len(ports):
                print("Invalid selection")
                return 1
        except (ValueError, EOFError):
            print("Invalid input")
            return 1
    
    # Open port
    midi_in.open_port(port_index)
    
    print(f"\nListening on: {ports[port_index]}")
    print("Press keys on your MIDI controller...")
    print("Press Ctrl+C to exit\n")
    print("-" * 50)
    print(f"{'Note':<10} {'Velocity':<10} {'Channel':<10} {'Action'}")
    print("-" * 50)
    
    notes_seen = set()
    
    try:
        while True:
            msg = midi_in.get_message()
            
            if msg:
                message, delta_time = msg
                
                if len(message) >= 3:
                    status, note, velocity = message[:3]
                    channel = (status & 0x0F) + 1
                    
                    # Note-on
                    if 0x90 <= status <= 0x9F and velocity > 0:
                        action = "NOTE ON"
                        if note not in notes_seen:
                            notes_seen.add(note)
                            action += " (NEW!)"
                        print(f"{note:<10} {velocity:<10} {channel:<10} {action}")
                    
                    # Note-off
                    elif (0x80 <= status <= 0x8F) or (0x90 <= status <= 0x9F and velocity == 0):
                        print(f"{note:<10} {velocity:<10} {channel:<10} NOTE OFF")
                    
                    # Control change
                    elif 0xB0 <= status <= 0xBF:
                        print(f"CC{note:<7} {velocity:<10} {channel:<10} CONTROL CHANGE")
            
            time.sleep(0.001)
            
    except KeyboardInterrupt:
        print("\n" + "-" * 50)
        print(f"\nNotes detected: {sorted(notes_seen)}")
        print("\nExample midi_mappings.yaml:")
        print("mappings:")
        for i, note in enumerate(sorted(notes_seen)[:4]):
            actions = ["record_toggle", "copy_to_clipboard", "clear_current", "undo_last"]
            if i < len(actions):
                print(f"  {note}: {actions[i]}")
    
    finally:
        midi_in.close_port()
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
