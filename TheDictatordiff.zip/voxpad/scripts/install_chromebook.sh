#!/bin/bash
# VoxPad Chromebook/Crostini Setup Script
#
# This script helps set up VoxPad on a Chromebook running Linux (Crostini)
#
# Usage:
#   chmod +x scripts/install_chromebook.sh
#   ./scripts/install_chromebook.sh

set -e

echo "================================"
echo "VoxPad Chromebook Setup"
echo "================================"
echo

# Check if we're in Crostini
if [ ! -f /etc/debian_version ]; then
    echo "Warning: This script is designed for Debian-based systems."
    echo "You may need to adapt it for your distribution."
    echo
fi

# Update package list
echo "Updating package list..."
sudo apt-get update

# Install system dependencies
echo
echo "Installing system dependencies..."
sudo apt-get install -y \
    python3 \
    python3-pip \
    python3-venv \
    portaudio19-dev \
    libasound2-dev \
    wl-clipboard \
    libnotify-bin

# Check for MIDI support
echo
echo "Checking MIDI support..."
if arecord -l &>/dev/null; then
    echo "✓ ALSA available"
else
    echo "✗ ALSA not available - MIDI may not work"
fi

# Create virtual environment
echo
echo "Creating Python virtual environment..."
python3 -m venv .venv
source .venv/bin/activate

# Install VoxPad
echo
echo "Installing VoxPad..."
pip install --upgrade pip
pip install -e ".[all]"

# Create user directories
echo
echo "Creating user directories..."
mkdir -p ~/.voxpad/{config,sessions,logs,models}

# Copy default configs if not exist
if [ ! -f ~/.voxpad/config/default.yaml ]; then
    cp config/default.yaml ~/.voxpad/config/
    echo "✓ Copied default config to ~/.voxpad/config/"
fi

if [ ! -f ~/.voxpad/config/midi_mappings.yaml ]; then
    cp config/midi_mappings.yaml ~/.voxpad/config/
    echo "✓ Copied MIDI mappings to ~/.voxpad/config/"
fi

# Test audio
echo
echo "Testing audio input..."
echo "Make sure you've enabled microphone access in Chrome OS settings:"
echo "  Settings > Linux > 'Allow Linux to access your microphone'"
echo

if arecord -d 1 /tmp/test_audio.wav &>/dev/null; then
    echo "✓ Audio recording works!"
    rm -f /tmp/test_audio.wav
else
    echo "✗ Audio recording failed"
    echo "  Check Chrome OS settings and try again"
fi

# Test clipboard
echo
echo "Testing clipboard..."
echo "test" | wl-copy
if [ "$(wl-paste)" = "test" ]; then
    echo "✓ Clipboard works!"
else
    echo "✗ Clipboard may have issues"
fi

# Check MIDI devices
echo
echo "Checking MIDI devices..."
python3 -c "
from voxpad.input.midi import MidiHandler
devices = MidiHandler.list_devices()
if devices:
    print('✓ MIDI devices found:')
    for d in devices:
        print(f'  - {d}')
else:
    print('✗ No MIDI devices found')
    print('  Connect your MIDI controller and run again')
"

echo
echo "================================"
echo "Setup Complete!"
echo "================================"
echo
echo "To run VoxPad:"
echo "  source .venv/bin/activate"
echo "  voxpad"
echo
echo "To test MIDI mappings:"
echo "  python scripts/test_midi_device.py"
echo
echo "To customize settings:"
echo "  Edit ~/.voxpad/config/default.yaml"
echo "  Edit ~/.voxpad/config/midi_mappings.yaml"
echo
