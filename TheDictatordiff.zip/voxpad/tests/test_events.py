"""Tests for the event bus system."""

import pytest

from voxpad.core.events import Event, EventBus, EventType


@pytest.fixture
def bus():
    """Provide a fresh EventBus for each test."""
    EventBus.reset()
    return EventBus()


def test_singleton(bus):
    """EventBus should be a singleton."""
    bus2 = EventBus()
    assert bus is bus2


def test_subscribe_and_emit(bus):
    """Basic subscribe and emit should work."""
    received = []
    
    def handler(event):
        received.append(event)
    
    bus.subscribe(EventType.RECORD_START, handler)
    bus.emit(Event(type=EventType.RECORD_START))
    
    assert len(received) == 1
    assert received[0].type == EventType.RECORD_START


def test_event_data(bus):
    """Events should carry data."""
    received = []
    
    def handler(event):
        received.append(event)
    
    bus.subscribe(EventType.TRANSCRIPTION_COMPLETE, handler)
    bus.emit(Event(
        type=EventType.TRANSCRIPTION_COMPLETE,
        data={"text": "Hello world", "language": "en"}
    ))
    
    assert received[0].data["text"] == "Hello world"
    assert received[0].data["language"] == "en"


def test_multiple_handlers(bus):
    """Multiple handlers should all be called."""
    calls = []
    
    def handler1(event):
        calls.append("h1")
    
    def handler2(event):
        calls.append("h2")
    
    bus.subscribe(EventType.RECORD_START, handler1)
    bus.subscribe(EventType.RECORD_START, handler2)
    bus.emit(Event(type=EventType.RECORD_START))
    
    assert "h1" in calls
    assert "h2" in calls


def test_priority(bus):
    """Higher priority handlers should run first."""
    order = []
    
    def low_priority(event):
        order.append("low")
    
    def high_priority(event):
        order.append("high")
    
    bus.subscribe(EventType.RECORD_START, low_priority, priority=0)
    bus.subscribe(EventType.RECORD_START, high_priority, priority=10)
    bus.emit(Event(type=EventType.RECORD_START))
    
    assert order == ["high", "low"]


def test_unsubscribe(bus):
    """Unsubscribed handlers should not be called."""
    calls = []
    
    def handler(event):
        calls.append(1)
    
    bus.subscribe(EventType.RECORD_START, handler)
    bus.unsubscribe(EventType.RECORD_START, handler)
    bus.emit(Event(type=EventType.RECORD_START))
    
    assert len(calls) == 0


def test_handler_exception_isolation(bus):
    """Exception in one handler should not stop others."""
    calls = []
    
    def bad_handler(event):
        raise ValueError("oops")
    
    def good_handler(event):
        calls.append("good")
    
    bus.subscribe(EventType.RECORD_START, bad_handler, priority=10)
    bus.subscribe(EventType.RECORD_START, good_handler, priority=0)
    bus.emit(Event(type=EventType.RECORD_START))
    
    assert "good" in calls


def test_history(bus):
    """Event history should be maintained."""
    bus.emit(Event(type=EventType.RECORD_START))
    bus.emit(Event(type=EventType.RECORD_STOP))
    
    history = bus.get_history()
    assert len(history) == 2
    assert history[0].type == EventType.RECORD_START
    assert history[1].type == EventType.RECORD_STOP


def test_filtered_history(bus):
    """History can be filtered by event type."""
    bus.emit(Event(type=EventType.RECORD_START))
    bus.emit(Event(type=EventType.RECORD_STOP))
    bus.emit(Event(type=EventType.RECORD_START))
    
    history = bus.get_history(EventType.RECORD_START)
    assert len(history) == 2
    assert all(e.type == EventType.RECORD_START for e in history)
