"""Tests for the session manager."""

import tempfile
from pathlib import Path

import pytest

from voxpad.core.events import Event, EventBus, EventType
from voxpad.core.session import Session, SessionEntry, SessionManager


@pytest.fixture
def bus():
    """Provide a fresh EventBus."""
    EventBus.reset()
    return EventBus()


@pytest.fixture
def temp_dir():
    """Provide a temporary directory for session files."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield tmpdir


@pytest.fixture
def session_manager(bus, temp_dir):
    """Provide a SessionManager with temp directory."""
    config = {
        "session": {
            "output_dir": temp_dir,
            "filename_format": "test_{timestamp}.md",
            "include_timestamps": True,
        }
    }
    manager = SessionManager(bus, config)
    yield manager
    manager.shutdown()


class TestSessionEntry:
    """Tests for SessionEntry dataclass."""
    
    def test_to_markdown_with_timestamp(self):
        """Entry should format to markdown with timestamp."""
        from datetime import datetime
        
        entry = SessionEntry(
            id="test123",
            text="Hello world",
            timestamp=datetime(2024, 1, 15, 10, 30, 45),
        )
        
        md = entry.to_markdown(include_timestamp=True)
        assert "### [10:30:45]" in md
        assert "Hello world" in md
    
    def test_to_markdown_edited(self):
        """Edited entry should show original."""
        from datetime import datetime
        
        entry = SessionEntry(
            id="test123",
            text="Edited text",
            timestamp=datetime.now(),
            edited=True,
            original_text="Original text",
        )
        
        md = entry.to_markdown()
        assert "Edited text" in md
        assert "*Original: Original text*" in md


class TestSession:
    """Tests for Session dataclass."""
    
    def test_add_entry(self):
        """Should add entries to session."""
        session = Session()
        entry = session.add_entry("Test text")
        
        assert len(session.entries) == 1
        assert entry.text == "Test text"
        assert session.last_entry == entry
    
    def test_remove_entry(self):
        """Should remove entries by ID."""
        session = Session()
        entry = session.add_entry("Test text")
        entry_id = entry.id
        
        assert session.remove_entry(entry_id) is True
        assert len(session.entries) == 0
    
    def test_all_text(self):
        """Should concatenate all entry text."""
        session = Session()
        session.add_entry("First")
        session.add_entry("Second")
        
        assert "First" in session.all_text
        assert "Second" in session.all_text


class TestSessionManager:
    """Tests for SessionManager."""
    
    def test_creates_session_file(self, session_manager, temp_dir):
        """Should create a session file on init."""
        files = list(Path(temp_dir).glob("*.md"))
        assert len(files) == 1
    
    def test_logs_transcription(self, bus, session_manager, temp_dir):
        """Should log transcription events."""
        bus.emit(Event(
            type=EventType.TRANSCRIPTION_COMPLETE,
            data={"text": "Test transcription", "language": "en"}
        ))
        
        # Check file contents
        files = list(Path(temp_dir).glob("*.md"))
        content = files[0].read_text()
        assert "Test transcription" in content
    
    def test_emits_session_updated(self, bus, session_manager):
        """Should emit SESSION_UPDATED event."""
        received = []
        
        def handler(event):
            received.append(event)
        
        bus.subscribe(EventType.SESSION_UPDATED, handler)
        bus.emit(Event(
            type=EventType.TRANSCRIPTION_COMPLETE,
            data={"text": "Test", "language": "en"}
        ))
        
        assert len(received) == 1
        assert received[0].data["text"] == "Test"
    
    def test_ignores_empty_transcription(self, bus, session_manager):
        """Should ignore empty transcriptions."""
        bus.emit(Event(
            type=EventType.TRANSCRIPTION_COMPLETE,
            data={"text": "   ", "language": "en"}
        ))
        
        assert len(session_manager.current_session.entries) == 0
    
    def test_get_last_text(self, bus, session_manager):
        """Should return last transcription text."""
        bus.emit(Event(
            type=EventType.TRANSCRIPTION_COMPLETE,
            data={"text": "First", "language": "en"}
        ))
        bus.emit(Event(
            type=EventType.TRANSCRIPTION_COMPLETE,
            data={"text": "Second", "language": "en"}
        ))
        
        assert session_manager.get_last_text() == "Second"
    
    def test_undo_last(self, bus, session_manager):
        """Should remove last entry."""
        bus.emit(Event(
            type=EventType.TRANSCRIPTION_COMPLETE,
            data={"text": "First", "language": "en"}
        ))
        bus.emit(Event(
            type=EventType.TRANSCRIPTION_COMPLETE,
            data={"text": "Second", "language": "en"}
        ))
        
        session_manager.undo_last()
        
        assert session_manager.get_last_text() == "First"
        assert len(session_manager.current_session.entries) == 1
