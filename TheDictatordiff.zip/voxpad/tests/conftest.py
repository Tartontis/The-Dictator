"""Pytest configuration and fixtures."""

import pytest

from voxpad.core.events import EventBus


@pytest.fixture(autouse=True)
def reset_event_bus():
    """Reset EventBus singleton before each test."""
    EventBus.reset()
    yield
    EventBus.reset()
