"""
VoxPad Entry Point

Run with: python -m voxpad
Or after install: voxpad
"""

from __future__ import annotations

import argparse
import sys


def main() -> int:
    """Main entry point for VoxPad."""
    parser = argparse.ArgumentParser(
        description="VoxPad - Local voice dictation with MIDI control"
    )
    parser.add_argument(
        "-c", "--config",
        help="Path to configuration file",
        default=None,
    )
    parser.add_argument(
        "--list-midi",
        action="store_true",
        help="List available MIDI devices and exit",
    )
    parser.add_argument(
        "--list-audio",
        action="store_true",
        help="List available audio devices and exit",
    )
    parser.add_argument(
        "--test-midi",
        action="store_true",
        help="Interactive MIDI test mode",
    )
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Enable debug logging",
    )
    
    args = parser.parse_args()
    
    # Handle device listing
    if args.list_midi:
        from voxpad.input.midi import MidiHandler
        devices = MidiHandler.list_devices()
        if devices:
            print("Available MIDI input devices:")
            for i, name in enumerate(devices):
                print(f"  [{i}] {name}")
        else:
            print("No MIDI input devices found")
        return 0
    
    if args.list_audio:
        from voxpad.input.audio import AudioCapture
        devices = AudioCapture.list_devices()
        if devices:
            print("Available audio input devices:")
            for dev in devices:
                print(f"  [{dev['index']}] {dev['name']} "
                      f"(channels={dev['channels']}, rate={dev['sample_rate']})")
        else:
            print("No audio input devices found")
        return 0
    
    if args.test_midi:
        # Run MIDI test script
        from scripts.test_midi_device import main as test_midi_main
        return test_midi_main()
    
    # Set up verbose logging if requested
    if args.verbose:
        import logging
        logging.basicConfig(level=logging.DEBUG)
    
    # Run the application
    from voxpad.app import VoxPadApp
    
    app = VoxPadApp(config_path=args.config)
    app.run()
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
