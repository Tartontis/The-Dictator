"""
VoxPad Extension Base

Protocol definition for VoxPad extensions.

Extensions can subscribe to events and add new functionality without
modifying core code.

Usage:
    from voxpad.extend.base import Extension
    from voxpad.core.events import EventBus
    
    class MyExtension(Extension):
        name = "my_extension"
        
        def initialize(self, bus: EventBus, config: dict) -> None:
            bus.subscribe(EventType.TRANSCRIPTION_COMPLETE, self.on_transcription)
        
        def shutdown(self) -> None:
            pass
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import Any, Protocol, runtime_checkable

from voxpad.core.events import EventBus

logger = logging.getLogger(__name__)


@runtime_checkable
class Extension(Protocol):
    """Protocol for VoxPad extensions.
    
    Extensions must implement:
    - name: Unique identifier string
    - initialize: Called on startup with EventBus and config
    - shutdown: Called on exit for cleanup
    """
    
    name: str
    
    def initialize(self, bus: EventBus, config: dict[str, Any]) -> None:
        """Initialize the extension.
        
        Subscribe to events and set up resources here.
        
        Args:
            bus: EventBus for event communication
            config: Extension-specific configuration
        """
        ...
    
    def shutdown(self) -> None:
        """Clean up extension resources."""
        ...


class BaseExtension(ABC):
    """Abstract base class for extensions.
    
    Provides common functionality for extensions.
    Subclass this for convenience, or implement Extension protocol directly.
    """
    
    name: str = "base"
    
    def __init__(self) -> None:
        self.bus: EventBus | None = None
        self.config: dict[str, Any] = {}
        self._initialized = False
    
    def initialize(self, bus: EventBus, config: dict[str, Any]) -> None:
        """Initialize the extension."""
        self.bus = bus
        self.config = config.get(self.name, {})
        self._setup()
        self._initialized = True
        logger.info(f"Extension '{self.name}' initialized")
    
    @abstractmethod
    def _setup(self) -> None:
        """Extension-specific setup. Override this."""
        ...
    
    def shutdown(self) -> None:
        """Clean up resources."""
        self._initialized = False
        logger.info(f"Extension '{self.name}' shut down")
    
    @property
    def is_initialized(self) -> bool:
        """Check if extension is initialized."""
        return self._initialized


class ExtensionManager:
    """Manages loading and lifecycle of extensions."""
    
    def __init__(self, bus: EventBus, config: dict[str, Any]) -> None:
        """Initialize the extension manager.
        
        Args:
            bus: EventBus for extensions to use
            config: Full configuration dict
        """
        self.bus = bus
        self.config = config
        self._extensions: dict[str, Extension] = {}
        
        # Load enabled extensions
        ext_config = config.get("extensions", {})
        enabled = ext_config.get("enabled", [])
        
        for ext_name in enabled:
            self._load_extension(ext_name)
    
    def _load_extension(self, name: str) -> bool:
        """Load an extension by name.
        
        Args:
            name: Extension name (matches module name in extend/)
            
        Returns:
            True if loaded successfully
        """
        try:
            # Dynamic import
            module = __import__(
                f"voxpad.extend.{name}",
                fromlist=[name]
            )
            
            # Look for extension class
            ext_class = getattr(module, "extension", None)
            if ext_class is None:
                # Try PascalCase class name
                class_name = "".join(
                    word.capitalize() for word in name.split("_")
                )
                ext_class = getattr(module, class_name, None)
            
            if ext_class is None:
                logger.error(f"No extension class found in {name}")
                return False
            
            # Instantiate and initialize
            ext = ext_class()
            ext.initialize(self.bus, self.config.get("extensions", {}))
            
            self._extensions[name] = ext
            logger.info(f"Loaded extension: {name}")
            return True
            
        except ImportError as e:
            logger.warning(f"Extension '{name}' not found: {e}")
            return False
        except Exception as e:
            logger.error(f"Failed to load extension '{name}': {e}")
            return False
    
    def get_extension(self, name: str) -> Extension | None:
        """Get a loaded extension by name."""
        return self._extensions.get(name)
    
    def shutdown(self) -> None:
        """Shutdown all extensions."""
        for name, ext in self._extensions.items():
            try:
                ext.shutdown()
            except Exception as e:
                logger.error(f"Error shutting down extension '{name}': {e}")
        
        self._extensions.clear()
        logger.info("ExtensionManager shut down")
