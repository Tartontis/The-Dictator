"""
VoxPad Browser Launcher Extension

Opens a browser to an LLM chat interface with transcription pre-filled.

Usage:
    # Enable in config:
    # extensions:
    #   enabled:
    #     - browser_launcher
    #   browser_launcher:
    #     default: claude
    #     targets:
    #       claude: "https://claude.ai/new"
    #       chatgpt: "https://chat.openai.com/"
"""

from __future__ import annotations

import logging
import urllib.parse
import webbrowser
from typing import Any

from voxpad.core.events import Event, EventBus, EventType
from voxpad.extend.base import BaseExtension

logger = logging.getLogger(__name__)


class BrowserLauncher(BaseExtension):
    """Opens browser to LLM chat with transcription.
    
    Subscribes to BROWSER_LAUNCH_REQUESTED and ACTION_TRIGGERED events.
    Emits BROWSER_LAUNCHED events.
    """
    
    name = "browser_launcher"
    
    # Default LLM targets
    DEFAULT_TARGETS = {
        "claude": "https://claude.ai/new",
        "chatgpt": "https://chat.openai.com/",
        "perplexity": "https://www.perplexity.ai/",
        "gemini": "https://gemini.google.com/",
    }
    
    def _setup(self) -> None:
        """Set up the browser launcher."""
        self.targets = self.config.get("targets", self.DEFAULT_TARGETS)
        self.default_target = self.config.get("default", "claude")
        
        # Subscribe to events
        self.bus.subscribe(EventType.BROWSER_LAUNCH_REQUESTED, self._on_launch_requested)
        self.bus.subscribe(EventType.ACTION_TRIGGERED, self._on_action)
    
    def _on_action(self, event: Event) -> None:
        """Handle action triggered events."""
        action = event.data.get("action", "")
        
        # Map action names to targets
        target_map = {
            "new_chat_claude": "claude",
            "new_chat_chatgpt": "chatgpt",
            "new_chat_perplexity": "perplexity",
            "new_chat_gemini": "gemini",
        }
        
        if action in target_map:
            self.bus.emit(Event(
                type=EventType.BROWSER_LAUNCH_REQUESTED,
                data={
                    "target": target_map[action],
                    "text": event.data.get("text", ""),
                }
            ))
    
    def _on_launch_requested(self, event: Event) -> None:
        """Handle browser launch request events."""
        target = event.data.get("target", self.default_target)
        text = event.data.get("text", "")
        
        try:
            url = self.launch(target, text)
            
            self.bus.emit(Event(
                type=EventType.BROWSER_LAUNCHED,
                data={"url": url}
            ))
            
        except Exception as e:
            logger.error(f"Browser launch failed: {e}")
    
    def launch(self, target: str, text: str = "") -> str:
        """Launch browser to LLM chat.
        
        Args:
            target: Target LLM (claude, chatgpt, etc.)
            text: Optional text to include (may be added to URL or clipboard)
            
        Returns:
            The URL that was opened
            
        Raises:
            ValueError: If target is unknown
        """
        if target not in self.targets:
            raise ValueError(f"Unknown target: {target}. Available: {list(self.targets.keys())}")
        
        base_url = self.targets[target]
        
        # Build URL with query parameter if supported
        # Note: Not all LLMs support query params for pre-filling
        # This is a best-effort approach
        if text:
            # URL-encode the text
            encoded_text = urllib.parse.quote(text)
            
            # Different services use different query params
            if "claude.ai" in base_url:
                # Claude doesn't currently support query params for text
                # Just open the base URL
                url = base_url
                logger.info(f"Note: Claude doesn't support pre-filled text via URL")
            elif "chat.openai.com" in base_url:
                # ChatGPT doesn't support query params either
                url = base_url
                logger.info(f"Note: ChatGPT doesn't support pre-filled text via URL")
            elif "perplexity.ai" in base_url:
                # Perplexity supports ?q= for search
                url = f"{base_url}?q={encoded_text}"
            else:
                # Try generic ?q= parameter
                separator = "&" if "?" in base_url else "?"
                url = f"{base_url}{separator}q={encoded_text}"
        else:
            url = base_url
        
        # Open browser
        logger.info(f"Opening browser: {url}")
        webbrowser.open(url)
        
        return url
    
    def shutdown(self) -> None:
        """Clean up resources."""
        self.bus.unsubscribe(EventType.BROWSER_LAUNCH_REQUESTED, self._on_launch_requested)
        self.bus.unsubscribe(EventType.ACTION_TRIGGERED, self._on_action)
        super().shutdown()


# Export for extension loader
extension = BrowserLauncher
