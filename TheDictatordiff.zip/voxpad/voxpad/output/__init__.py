"""VoxPad Output Layer - Clipboard, notifications, and GUI."""

from voxpad.output.clipboard import ClipboardManager
from voxpad.output.notifications import NotificationManager

__all__ = [
    "ClipboardManager",
    "NotificationManager",
]
