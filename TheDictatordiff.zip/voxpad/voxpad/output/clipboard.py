"""
VoxPad Clipboard Manager

Handles copying transcriptions to the system clipboard.
Supports multiple backends: wl-copy (Wayland), xclip (X11), xsel.

Usage:
    from voxpad.output.clipboard import ClipboardManager
    from voxpad.core.events import EventBus
    
    clipboard = ClipboardManager(EventBus(), config)
    # Automatically copies on TRANSCRIPTION_COMPLETE if auto_copy enabled
"""

from __future__ import annotations

import logging
import shutil
import subprocess
from typing import Any

from voxpad.core.events import Event, EventBus, EventType

logger = logging.getLogger(__name__)


class ClipboardManager:
    """Manages clipboard operations.
    
    Subscribes to TRANSCRIPTION_COMPLETE and ACTION_TRIGGERED events.
    Emits COPY_COMPLETE or COPY_ERROR events.
    
    Attributes:
        auto_copy: Whether to automatically copy transcriptions
        backend: Clipboard tool to use (wl-copy, xclip, xsel, or auto)
    """
    
    # Clipboard backends in preference order
    BACKENDS = ["wl-copy", "xclip", "xsel"]
    
    def __init__(self, bus: EventBus, config: dict[str, Any]) -> None:
        """Initialize the clipboard manager.
        
        Args:
            bus: EventBus for event communication
            config: Configuration with 'clipboard' section
        """
        self.bus = bus
        
        clip_config = config.get("clipboard", {})
        self.auto_copy = clip_config.get("auto_copy", True)
        self._backend = clip_config.get("backend", "auto")
        
        # Detect backend if auto
        if self._backend == "auto":
            self._backend = self._detect_backend()
        
        self._last_copied: str | None = None
        
        # Subscribe to events
        self.bus.subscribe(EventType.TRANSCRIPTION_COMPLETE, self._on_transcription)
        self.bus.subscribe(EventType.ACTION_TRIGGERED, self._on_action)
        
        logger.info(f"ClipboardManager initialized (backend={self._backend})")
    
    def _detect_backend(self) -> str | None:
        """Detect available clipboard backend."""
        for backend in self.BACKENDS:
            if shutil.which(backend):
                logger.debug(f"Detected clipboard backend: {backend}")
                return backend
        
        logger.warning("No clipboard backend found")
        return None
    
    def _on_transcription(self, event: Event) -> None:
        """Handle transcription complete events."""
        if not self.auto_copy:
            return
        
        text = event.data.get("text", "")
        if text.strip():
            self.copy(text)
    
    def _on_action(self, event: Event) -> None:
        """Handle action triggered events."""
        action = event.data.get("action")
        if action == "copy_to_clipboard" and self._last_copied:
            self.copy(self._last_copied)
    
    def copy(self, text: str) -> bool:
        """Copy text to clipboard.
        
        Args:
            text: Text to copy
            
        Returns:
            True if successful, False otherwise
        """
        if not self._backend:
            logger.error("No clipboard backend available")
            self.bus.emit(Event(
                type=EventType.COPY_ERROR,
                data={"error": "No clipboard backend available"}
            ))
            return False
        
        try:
            # Build command based on backend
            if self._backend == "wl-copy":
                cmd = ["wl-copy"]
            elif self._backend == "xclip":
                cmd = ["xclip", "-selection", "clipboard"]
            elif self._backend == "xsel":
                cmd = ["xsel", "--clipboard", "--input"]
            else:
                raise ValueError(f"Unknown backend: {self._backend}")
            
            # Run command
            proc = subprocess.run(
                cmd,
                input=text.encode("utf-8"),
                capture_output=True,
                timeout=5,
            )
            
            if proc.returncode != 0:
                raise RuntimeError(proc.stderr.decode())
            
            self._last_copied = text
            
            self.bus.emit(Event(
                type=EventType.COPY_COMPLETE,
                data={"text": text}
            ))
            
            logger.debug(f"Copied to clipboard: {text[:50]}...")
            return True
            
        except subprocess.TimeoutExpired:
            logger.error("Clipboard operation timed out")
            self.bus.emit(Event(
                type=EventType.COPY_ERROR,
                data={"error": "Clipboard operation timed out"}
            ))
            return False
            
        except Exception as e:
            logger.error(f"Clipboard error: {e}")
            self.bus.emit(Event(
                type=EventType.COPY_ERROR,
                data={"error": str(e)}
            ))
            return False
    
    def get_last_copied(self) -> str | None:
        """Get the last copied text."""
        return self._last_copied
    
    def shutdown(self) -> None:
        """Clean up resources."""
        self.bus.unsubscribe(EventType.TRANSCRIPTION_COMPLETE, self._on_transcription)
        self.bus.unsubscribe(EventType.ACTION_TRIGGERED, self._on_action)
        logger.info("ClipboardManager shut down")
