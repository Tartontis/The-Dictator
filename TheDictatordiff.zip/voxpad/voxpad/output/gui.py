"""
VoxPad GUI

Optional TUI interface for editing transcriptions and viewing status.

This is a stub for future implementation using Textual.

Usage:
    from voxpad.output.gui import GUI
    from voxpad.core.events import EventBus
    
    gui = GUI(EventBus(), config)
    gui.run()  # Blocks until exit
"""

from __future__ import annotations

import logging
from typing import Any

from voxpad.core.events import EventBus

logger = logging.getLogger(__name__)


class GUI:
    """Optional TUI interface.
    
    Provides:
    - Live recording status
    - Transcription editing
    - Session history view
    - VU meter display
    
    Requires the 'gui' extra: pip install voxpad[gui]
    """
    
    def __init__(self, bus: EventBus, config: dict[str, Any]) -> None:
        """Initialize the GUI.
        
        Args:
            bus: EventBus for event communication
            config: Configuration with 'gui' section
        """
        self.bus = bus
        self.config = config.get("gui", {})
        self.enabled = self.config.get("enabled", False)
        
        logger.info("GUI initialized (stub implementation)")
    
    def run(self) -> None:
        """Run the GUI (blocking).
        
        Raises:
            NotImplementedError: GUI not yet implemented
        """
        if not self.enabled:
            logger.info("GUI disabled in config")
            return
        
        raise NotImplementedError(
            "GUI not yet implemented. "
            "Set gui.enabled: false in config or contribute an implementation!"
        )
    
    def shutdown(self) -> None:
        """Clean up resources."""
        logger.info("GUI shut down")


# TODO: Implement using Textual
# 
# from textual.app import App
# from textual.widgets import Header, Footer, Static, Input
# 
# class VoxPadApp(App):
#     BINDINGS = [
#         ("q", "quit", "Quit"),
#         ("r", "record", "Record"),
#         ("c", "copy", "Copy"),
#     ]
#     
#     def compose(self):
#         yield Header()
#         yield Static("Status: Ready", id="status")
#         yield Static("", id="transcription")
#         yield Input(placeholder="Edit transcription...")
#         yield Footer()
