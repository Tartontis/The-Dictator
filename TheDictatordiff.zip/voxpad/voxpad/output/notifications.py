"""
VoxPad Notifications

Handles desktop notifications for user feedback.

Usage:
    from voxpad.output.notifications import NotificationManager
    from voxpad.core.events import EventBus
    
    notifier = NotificationManager(EventBus(), config)
    # Automatically shows notifications on relevant events
"""

from __future__ import annotations

import logging
import shutil
import subprocess
from typing import Any

from voxpad.core.events import Event, EventBus, EventType

logger = logging.getLogger(__name__)


class NotificationManager:
    """Manages desktop notifications.
    
    Shows notifications for transcription completion, errors, etc.
    Uses notify-send on Linux.
    """
    
    def __init__(self, bus: EventBus, config: dict[str, Any]) -> None:
        """Initialize the notification manager.
        
        Args:
            bus: EventBus for event communication
            config: Configuration with 'notifications' section
        """
        self.bus = bus
        
        notif_config = config.get("notifications", {})
        self.enabled = notif_config.get("enabled", True)
        self.duration = notif_config.get("duration", 3)  # seconds
        self.preview_length = notif_config.get("preview_length", 50)
        
        self._has_notify_send = shutil.which("notify-send") is not None
        
        if self.enabled and not self._has_notify_send:
            logger.warning("notify-send not found - notifications disabled")
            self.enabled = False
        
        # Subscribe to events
        self.bus.subscribe(EventType.RECORD_START, self._on_record_start)
        self.bus.subscribe(EventType.TRANSCRIPTION_COMPLETE, self._on_transcription)
        self.bus.subscribe(EventType.TRANSCRIPTION_ERROR, self._on_error)
        self.bus.subscribe(EventType.COPY_COMPLETE, self._on_copy)
        
        logger.info(f"NotificationManager initialized (enabled={self.enabled})")
    
    def _on_record_start(self, event: Event) -> None:
        """Handle record start events."""
        self.notify("VoxPad", "🎙️ Recording...", urgency="low")
    
    def _on_transcription(self, event: Event) -> None:
        """Handle transcription complete events."""
        text = event.data.get("text", "")
        preview = text[:self.preview_length]
        if len(text) > self.preview_length:
            preview += "..."
        
        self.notify("Transcription Complete", preview)
    
    def _on_error(self, event: Event) -> None:
        """Handle error events."""
        error = event.data.get("error", "Unknown error")
        self.notify("VoxPad Error", f"❌ {error}", urgency="critical")
    
    def _on_copy(self, event: Event) -> None:
        """Handle copy complete events."""
        text = event.data.get("text", "")
        preview = text[:30]
        if len(text) > 30:
            preview += "..."
        
        self.notify("Copied", f"📋 {preview}", urgency="low")
    
    def notify(
        self,
        title: str,
        body: str,
        urgency: str = "normal",
        icon: str | None = None
    ) -> bool:
        """Show a desktop notification.
        
        Args:
            title: Notification title
            body: Notification body text
            urgency: low, normal, or critical
            icon: Optional icon name or path
            
        Returns:
            True if notification was sent, False otherwise
        """
        if not self.enabled:
            return False
        
        try:
            cmd = [
                "notify-send",
                "--urgency", urgency,
                "--expire-time", str(self.duration * 1000),  # ms
            ]
            
            if icon:
                cmd.extend(["--icon", icon])
            
            cmd.extend([title, body])
            
            subprocess.run(cmd, capture_output=True, timeout=5)
            return True
            
        except Exception as e:
            logger.debug(f"Notification failed: {e}")
            return False
    
    def shutdown(self) -> None:
        """Clean up resources."""
        self.bus.unsubscribe(EventType.RECORD_START, self._on_record_start)
        self.bus.unsubscribe(EventType.TRANSCRIPTION_COMPLETE, self._on_transcription)
        self.bus.unsubscribe(EventType.TRANSCRIPTION_ERROR, self._on_error)
        self.bus.unsubscribe(EventType.COPY_COMPLETE, self._on_copy)
        logger.info("NotificationManager shut down")
