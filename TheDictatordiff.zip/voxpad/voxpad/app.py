"""
VoxPad Application

Main application coordinator that initializes and manages all components.

Usage:
    from voxpad.app import VoxPadApp
    
    app = VoxPadApp()
    app.run()  # Blocks until shutdown
"""

from __future__ import annotations

import logging
import signal
import sys
import threading
from pathlib import Path
from typing import Any

import yaml

from voxpad.core.events import Event, EventBus, EventType
from voxpad.core.session import SessionManager
from voxpad.core.transcriber import Transcriber
from voxpad.extend.base import ExtensionManager
from voxpad.input.audio import AudioCapture
from voxpad.input.midi import MidiHandler
from voxpad.output.clipboard import ClipboardManager
from voxpad.output.notifications import NotificationManager

logger = logging.getLogger(__name__)


class VoxPadApp:
    """Main VoxPad application.
    
    Coordinates all components and manages the application lifecycle.
    """
    
    def __init__(self, config_path: str | Path | None = None) -> None:
        """Initialize the application.
        
        Args:
            config_path: Path to config file, or None for default
        """
        self.config = self._load_config(config_path)
        self._setup_logging()
        
        # Initialize event bus
        self.bus = EventBus()
        
        # Initialize components (order matters)
        self._components: list[Any] = []
        self._shutdown_event = threading.Event()
        
        logger.info("VoxPad initializing...")
    
    def _load_config(self, config_path: str | Path | None) -> dict[str, Any]:
        """Load configuration from file."""
        # Default config locations
        default_paths = [
            Path("config/default.yaml"),  # Local dev
            Path.home() / ".voxpad" / "config" / "default.yaml",  # User
            Path(__file__).parent.parent / "config" / "default.yaml",  # Package
        ]
        
        if config_path:
            paths = [Path(config_path)]
        else:
            paths = default_paths
        
        config = {}
        
        for path in paths:
            if path.exists():
                logger.debug(f"Loading config from: {path}")
                with open(path) as f:
                    config = yaml.safe_load(f) or {}
                break
        
        # Load MIDI mappings
        midi_paths = [
            Path("config/midi_mappings.yaml"),
            Path.home() / ".voxpad" / "config" / "midi_mappings.yaml",
            Path(__file__).parent.parent / "config" / "midi_mappings.yaml",
        ]
        
        for path in midi_paths:
            if path.exists():
                logger.debug(f"Loading MIDI mappings from: {path}")
                with open(path) as f:
                    config["midi_mappings"] = yaml.safe_load(f) or {}
                break
        
        return config
    
    def _setup_logging(self) -> None:
        """Configure logging based on config."""
        log_config = self.config.get("logging", {})
        level = getattr(logging, log_config.get("level", "INFO").upper())
        
        # Configure root logger
        logging.basicConfig(
            level=level,
            format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            datefmt="%H:%M:%S",
        )
        
        # File logging if configured
        log_file = log_config.get("file")
        if log_file:
            log_path = Path(log_file).expanduser()
            log_path.parent.mkdir(parents=True, exist_ok=True)
            
            file_handler = logging.FileHandler(log_path)
            file_handler.setFormatter(logging.Formatter(
                "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
            ))
            logging.getLogger().addHandler(file_handler)
    
    def _init_components(self) -> None:
        """Initialize all application components."""
        # Core components
        self.session = SessionManager(self.bus, self.config)
        self._components.append(self.session)
        
        self.transcriber = Transcriber(self.bus, self.config)
        self._components.append(self.transcriber)
        
        # Input components
        self.audio = AudioCapture(self.bus, self.config)
        self._components.append(self.audio)
        
        self.midi = MidiHandler(self.bus, self.config)
        self._components.append(self.midi)
        
        # Output components
        self.clipboard = ClipboardManager(self.bus, self.config)
        self._components.append(self.clipboard)
        
        self.notifications = NotificationManager(self.bus, self.config)
        self._components.append(self.notifications)
        
        # Extensions
        self.extensions = ExtensionManager(self.bus, self.config)
        self._components.append(self.extensions)
        
        # Subscribe to shutdown events
        self.bus.subscribe(EventType.SHUTDOWN_REQUESTED, self._on_shutdown)
    
    def _on_shutdown(self, event: Event) -> None:
        """Handle shutdown event."""
        self._shutdown_event.set()
    
    def run(self) -> None:
        """Run the application (blocking)."""
        try:
            self._init_components()
            
            # Setup signal handlers
            signal.signal(signal.SIGINT, self._signal_handler)
            signal.signal(signal.SIGTERM, self._signal_handler)
            
            # Start input handlers
            self.audio.start()
            self.midi.start()
            
            # Preload model in background
            threading.Thread(
                target=self.transcriber.preload_model,
                daemon=True
            ).start()
            
            logger.info("VoxPad ready! Press MIDI pad or Ctrl+C to exit.")
            
            # Wait for shutdown
            self._shutdown_event.wait()
            
        except KeyboardInterrupt:
            logger.info("Interrupted")
        except Exception as e:
            logger.exception(f"Fatal error: {e}")
            sys.exit(1)
        finally:
            self.shutdown()
    
    def _signal_handler(self, signum: int, frame: Any) -> None:
        """Handle termination signals."""
        logger.info(f"Received signal {signum}")
        self._shutdown_event.set()
    
    def shutdown(self) -> None:
        """Shutdown all components."""
        logger.info("Shutting down...")
        
        # Emit shutdown event
        self.bus.emit(Event(type=EventType.SHUTDOWN_REQUESTED))
        
        # Shutdown components in reverse order
        for component in reversed(self._components):
            try:
                if hasattr(component, "shutdown"):
                    component.shutdown()
            except Exception as e:
                logger.error(f"Error shutting down {component}: {e}")
        
        # Reset event bus
        EventBus.reset()
        
        logger.info("VoxPad shut down")
