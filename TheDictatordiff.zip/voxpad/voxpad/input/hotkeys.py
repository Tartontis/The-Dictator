"""
VoxPad Hotkey Handler

Keyboard hotkey fallback for when MIDI controller is not available.
Uses pynput for cross-platform hotkey detection.

Usage:
    from voxpad.input.hotkeys import HotkeyHandler
    from voxpad.core.events import EventBus
    
    handler = HotkeyHandler(EventBus(), config)
    handler.start()
"""

from __future__ import annotations

import logging
from typing import Any

from voxpad.core.events import Event, EventBus, EventType
from voxpad.input.base import InputHandler

logger = logging.getLogger(__name__)

# Lazy import pynput
pynput_keyboard = None


def _get_pynput():
    """Lazy load pynput keyboard module."""
    global pynput_keyboard
    if pynput_keyboard is None:
        try:
            from pynput import keyboard
            pynput_keyboard = keyboard
        except ImportError:
            logger.warning("pynput not installed - hotkeys unavailable")
            return None
    return pynput_keyboard


class HotkeyHandler(InputHandler):
    """Handles keyboard hotkeys as MIDI alternative.
    
    Provides a fallback input method when no MIDI controller is available.
    Default hotkey is Ctrl+Shift+Space for record toggle.
    """
    
    # Default hotkey mappings
    DEFAULT_HOTKEYS = {
        "<ctrl>+<shift>+space": "record_toggle",
        "<ctrl>+<shift>+c": "copy_to_clipboard",
        "<ctrl>+<shift>+z": "undo_last",
        "<ctrl>+<shift>+x": "clear_current",
    }
    
    def __init__(self, bus: EventBus, config: dict[str, Any]) -> None:
        """Initialize the hotkey handler.
        
        Args:
            bus: EventBus for event communication
            config: Configuration with optional 'hotkeys' section
        """
        super().__init__(bus, config)
        
        hotkey_config = config.get("hotkeys", {})
        self.hotkeys = hotkey_config.get("mappings", self.DEFAULT_HOTKEYS)
        self.enabled = hotkey_config.get("enabled", True)
        
        self._listener = None
        self._recording = False
        self._current_keys: set = set()
        
        logger.info(f"HotkeyHandler initialized with {len(self.hotkeys)} hotkeys")
    
    def start(self) -> None:
        """Start listening for hotkeys."""
        if self._running:
            logger.warning("HotkeyHandler already running")
            return
        
        if not self.enabled:
            logger.info("Hotkeys disabled in config")
            return
        
        keyboard = _get_pynput()
        if keyboard is None:
            logger.warning("Cannot start hotkey handler - pynput not available")
            return
        
        try:
            # Create hotkey combinations
            hotkey_actions = {}
            for combo, action in self.hotkeys.items():
                try:
                    hotkey = keyboard.HotKey(
                        keyboard.HotKey.parse(combo),
                        lambda a=action: self._on_hotkey(a)
                    )
                    hotkey_actions[combo] = hotkey
                except Exception as e:
                    logger.warning(f"Invalid hotkey '{combo}': {e}")
            
            self._hotkey_actions = hotkey_actions
            
            # Start listener
            self._listener = keyboard.Listener(
                on_press=self._on_press,
                on_release=self._on_release,
            )
            self._listener.start()
            
            self._running = True
            logger.info(f"Hotkey listener started ({len(hotkey_actions)} hotkeys active)")
            
        except Exception as e:
            logger.error(f"Failed to start hotkey handler: {e}")
    
    def stop(self) -> None:
        """Stop listening for hotkeys."""
        if not self._running:
            return
        
        if self._listener:
            self._listener.stop()
            self._listener = None
        
        self._running = False
        logger.info("HotkeyHandler stopped")
    
    def _on_press(self, key) -> None:
        """Handle key press events."""
        for hotkey in self._hotkey_actions.values():
            hotkey.press(self._listener.canonical(key))
    
    def _on_release(self, key) -> None:
        """Handle key release events."""
        for hotkey in self._hotkey_actions.values():
            hotkey.release(self._listener.canonical(key))
    
    def _on_hotkey(self, action: str) -> None:
        """Handle a hotkey activation.
        
        Args:
            action: Name of the action to trigger
        """
        logger.info(f"Hotkey triggered: {action}")
        
        if action == "record_toggle":
            self._handle_record_toggle()
        else:
            self.bus.emit(Event(
                type=EventType.ACTION_TRIGGERED,
                data={
                    "action": action,
                    "source": "hotkey",
                    "velocity": 100,  # Simulate full velocity
                }
            ))
    
    def _handle_record_toggle(self) -> None:
        """Toggle recording state."""
        if self._recording:
            self._recording = False
            self.bus.emit(Event(type=EventType.RECORD_STOP))
        else:
            self._recording = True
            self.bus.emit(Event(type=EventType.RECORD_START))
