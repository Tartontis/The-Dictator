"""
VoxPad Input Layer Base

Abstract base classes and protocols for input handlers.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from voxpad.core.events import EventBus


class InputHandler(ABC):
    """Abstract base class for input handlers.
    
    Input handlers capture user intent from physical devices (MIDI, keyboard, etc.)
    and emit events to the EventBus.
    """
    
    def __init__(self, bus: EventBus, config: dict[str, Any]) -> None:
        """Initialize the input handler.
        
        Args:
            bus: EventBus for emitting events
            config: Handler-specific configuration
        """
        self.bus = bus
        self.config = config
        self._running = False
    
    @abstractmethod
    def start(self) -> None:
        """Start listening for input."""
        ...
    
    @abstractmethod
    def stop(self) -> None:
        """Stop listening for input."""
        ...
    
    @property
    def is_running(self) -> bool:
        """Check if the handler is currently running."""
        return self._running
    
    def shutdown(self) -> None:
        """Clean up resources."""
        if self._running:
            self.stop()
