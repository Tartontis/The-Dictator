"""
VoxPad MIDI Input Handler

Listens for MIDI note-on events from a drum pad controller and
maps them to VoxPad actions.

Usage:
    from voxpad.input.midi import MidiHandler
    from voxpad.core.events import EventBus
    
    handler = MidiHandler(EventBus(), config)
    handler.start()  # Begin listening
"""

from __future__ import annotations

import logging
import threading
from typing import Any, Callable

from voxpad.core.events import Event, EventBus, EventType
from voxpad.input.base import InputHandler

logger = logging.getLogger(__name__)

# Lazy import rtmidi
rtmidi = None


def _get_rtmidi():
    """Lazy load rtmidi."""
    global rtmidi
    if rtmidi is None:
        import rtmidi as _rtmidi
        rtmidi = _rtmidi
    return rtmidi


class MidiHandler(InputHandler):
    """Handles MIDI input from drum pad controllers.
    
    Maps MIDI note-on events to VoxPad actions based on configuration.
    Emits ACTION_TRIGGERED events when mapped notes are pressed.
    
    Attributes:
        device_name: Name of the MIDI device (None for auto-detect)
        mappings: Dict mapping note numbers to action names
    """
    
    # Action name -> EventType mapping
    ACTION_EVENTS: dict[str, EventType] = {
        "record_toggle": EventType.ACTION_TRIGGERED,
        "copy_to_clipboard": EventType.ACTION_TRIGGERED,
        "clear_current": EventType.ACTION_TRIGGERED,
        "undo_last": EventType.ACTION_TRIGGERED,
        "refine_prompt": EventType.REFINEMENT_REQUESTED,
        "new_chat_claude": EventType.BROWSER_LAUNCH_REQUESTED,
        "new_chat_chatgpt": EventType.BROWSER_LAUNCH_REQUESTED,
        "new_chat_perplexity": EventType.BROWSER_LAUNCH_REQUESTED,
    }
    
    def __init__(self, bus: EventBus, config: dict[str, Any]) -> None:
        """Initialize the MIDI handler.
        
        Args:
            bus: EventBus for event communication
            config: Configuration with 'midi_mappings' section
        """
        super().__init__(bus, config)
        
        midi_config = config.get("midi_mappings", {})
        self.device_name = midi_config.get("device_name")
        self.mappings = midi_config.get("mappings", {})
        self.velocity_sensitive = midi_config.get("velocity_sensitive", False)
        
        # Convert string keys to int (YAML may load them as strings)
        self.mappings = {int(k): v for k, v in self.mappings.items()}
        
        self._midi_in = None
        self._recording = False
        self._action_handlers: dict[str, Callable] = {}
        
        # Register default action handlers
        self._register_default_handlers()
        
        logger.info(f"MidiHandler initialized with {len(self.mappings)} mappings")
    
    def _register_default_handlers(self) -> None:
        """Register handlers for built-in actions."""
        self._action_handlers = {
            "record_toggle": self._handle_record_toggle,
            "copy_to_clipboard": self._handle_copy,
            "clear_current": self._handle_clear,
            "undo_last": self._handle_undo,
        }
    
    def start(self) -> None:
        """Start listening for MIDI input."""
        if self._running:
            logger.warning("MidiHandler already running")
            return
        
        try:
            _rtmidi = _get_rtmidi()
            self._midi_in = _rtmidi.MidiIn()
            
            # Find device
            ports = self._midi_in.get_ports()
            if not ports:
                logger.warning("No MIDI input devices found")
                return
            
            port_index = 0
            if self.device_name:
                # Find specific device
                for i, name in enumerate(ports):
                    if self.device_name.lower() in name.lower():
                        port_index = i
                        break
                else:
                    logger.warning(f"Device '{self.device_name}' not found, using first device")
            
            self._midi_in.open_port(port_index)
            self._midi_in.set_callback(self._midi_callback)
            
            self._running = True
            logger.info(f"Listening on MIDI port: {ports[port_index]}")
            
        except Exception as e:
            logger.error(f"Failed to start MIDI handler: {e}")
            self._midi_in = None
    
    def stop(self) -> None:
        """Stop listening for MIDI input."""
        if not self._running:
            return
        
        if self._midi_in:
            self._midi_in.close_port()
            self._midi_in = None
        
        self._running = False
        logger.info("MidiHandler stopped")
    
    def _midi_callback(self, message: tuple, data: Any = None) -> None:
        """Handle incoming MIDI messages.
        
        Args:
            message: Tuple of (midi_data, delta_time)
            data: Optional user data (unused)
        """
        midi_data, _ = message
        
        if len(midi_data) < 3:
            return
        
        status, note, velocity = midi_data[:3]
        
        # Note-on is 0x90-0x9F, note-off is 0x80-0x8F
        # Some controllers send note-on with velocity 0 for note-off
        is_note_on = (0x90 <= status <= 0x9F) and velocity > 0
        
        if not is_note_on:
            return
        
        logger.debug(f"MIDI note-on: note={note}, velocity={velocity}")
        
        # Look up action
        action = self.mappings.get(note)
        if action is None:
            logger.debug(f"Note {note} not mapped")
            return
        
        # Handle the action
        self._handle_action(action, velocity)
    
    def _handle_action(self, action: str, velocity: int) -> None:
        """Handle a mapped action.
        
        Args:
            action: Name of the action
            velocity: MIDI velocity (0-127)
        """
        logger.info(f"Action triggered: {action} (velocity={velocity})")
        
        # Check for built-in handler
        handler = self._action_handlers.get(action)
        if handler:
            handler(velocity)
            return
        
        # Emit generic action event for extensions
        self.bus.emit(Event(
            type=EventType.ACTION_TRIGGERED,
            data={
                "action": action,
                "source": "midi",
                "velocity": velocity,
            }
        ))
    
    def _handle_record_toggle(self, velocity: int) -> None:
        """Toggle recording state."""
        if self._recording:
            self._recording = False
            self.bus.emit(Event(type=EventType.RECORD_STOP))
        else:
            self._recording = True
            self.bus.emit(Event(type=EventType.RECORD_START))
    
    def _handle_copy(self, velocity: int) -> None:
        """Request copy to clipboard."""
        self.bus.emit(Event(
            type=EventType.ACTION_TRIGGERED,
            data={"action": "copy_to_clipboard", "source": "midi", "velocity": velocity}
        ))
    
    def _handle_clear(self, velocity: int) -> None:
        """Request clear current."""
        self.bus.emit(Event(
            type=EventType.ACTION_TRIGGERED,
            data={"action": "clear_current", "source": "midi", "velocity": velocity}
        ))
    
    def _handle_undo(self, velocity: int) -> None:
        """Request undo last."""
        self.bus.emit(Event(
            type=EventType.ACTION_TRIGGERED,
            data={"action": "undo_last", "source": "midi", "velocity": velocity}
        ))
    
    @staticmethod
    def list_devices() -> list[str]:
        """List available MIDI input devices."""
        try:
            _rtmidi = _get_rtmidi()
            midi_in = _rtmidi.MidiIn()
            ports = midi_in.get_ports()
            del midi_in
            return ports
        except Exception as e:
            logger.error(f"Failed to list MIDI devices: {e}")
            return []
