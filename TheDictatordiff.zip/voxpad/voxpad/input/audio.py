"""
VoxPad Audio Capture

Handles microphone input and audio recording.

Subscribes to RECORD_START and RECORD_STOP events, emits AUDIO_READY
when recording is complete.

Usage:
    from voxpad.input.audio import AudioCapture
    from voxpad.core.events import EventBus
    
    capture = AudioCapture(EventBus(), config)
    # AudioCapture automatically handles recording based on events
"""

from __future__ import annotations

import logging
import threading
import time
from typing import Any

import numpy as np

from voxpad.core.events import Event, EventBus, EventType
from voxpad.input.base import InputHandler

logger = logging.getLogger(__name__)

# Lazy import sounddevice
sd = None


def _get_sounddevice():
    """Lazy load sounddevice."""
    global sd
    if sd is None:
        import sounddevice as _sd
        sd = _sd
    return sd


class AudioCapture(InputHandler):
    """Handles audio capture from microphone.
    
    Subscribes to RECORD_START/STOP events and captures audio.
    Emits AUDIO_READY when recording is complete.
    
    Attributes:
        sample_rate: Audio sample rate (default 16000 for Whisper)
        channels: Number of audio channels (1 for mono)
        device_index: Audio device index (None for system default)
    """
    
    def __init__(self, bus: EventBus, config: dict[str, Any]) -> None:
        """Initialize audio capture.
        
        Args:
            bus: EventBus for event communication
            config: Configuration with 'audio' section
        """
        super().__init__(bus, config)
        
        audio_config = config.get("audio", {})
        self.sample_rate = audio_config.get("sample_rate", 16000)
        self.channels = audio_config.get("channels", 1)
        self.device_index = audio_config.get("device_index")
        self.max_duration = audio_config.get("max_duration", 300)
        
        self._recording = False
        self._audio_buffer: list[np.ndarray] = []
        self._record_start_time: float = 0
        self._stream = None
        self._lock = threading.Lock()
        
        # Subscribe to recording events
        self.bus.subscribe(EventType.RECORD_START, self._on_record_start)
        self.bus.subscribe(EventType.RECORD_STOP, self._on_record_stop)
        self.bus.subscribe(EventType.SHUTDOWN_REQUESTED, self._on_shutdown)
        
        logger.info(
            f"AudioCapture initialized (rate={self.sample_rate}, "
            f"channels={self.channels})"
        )
    
    def start(self) -> None:
        """Start the audio system (not recording, just ready)."""
        if self._running:
            return
        
        try:
            _sd = _get_sounddevice()
            
            # Verify device is available
            if self.device_index is not None:
                _sd.check_input_settings(
                    device=self.device_index,
                    samplerate=self.sample_rate,
                    channels=self.channels,
                )
            
            self._running = True
            logger.info("Audio system ready")
            
        except Exception as e:
            logger.error(f"Failed to initialize audio: {e}")
            raise
    
    def stop(self) -> None:
        """Stop the audio system."""
        if not self._running:
            return
        
        self._stop_recording()
        self._running = False
        logger.info("Audio system stopped")
    
    def _on_record_start(self, event: Event) -> None:
        """Handle record start event."""
        self._start_recording()
    
    def _on_record_stop(self, event: Event) -> None:
        """Handle record stop event."""
        audio = self._stop_recording()
        if audio is not None and len(audio) > 0:
            duration = len(audio) / self.sample_rate
            logger.info(f"Recording complete: {duration:.1f}s")
            
            self.bus.emit(Event(
                type=EventType.AUDIO_READY,
                data={
                    "audio": audio,
                    "sample_rate": self.sample_rate,
                    "duration": duration,
                }
            ))
    
    def _on_shutdown(self, event: Event) -> None:
        """Handle shutdown event."""
        self.stop()
    
    def _start_recording(self) -> None:
        """Start recording audio."""
        if self._recording:
            logger.warning("Already recording")
            return
        
        _sd = _get_sounddevice()
        
        with self._lock:
            self._audio_buffer.clear()
            self._record_start_time = time.time()
            self._recording = True
        
        def audio_callback(indata, frames, time_info, status):
            """Callback for audio stream."""
            if status:
                logger.warning(f"Audio status: {status}")
            
            if self._recording:
                # Check max duration
                elapsed = time.time() - self._record_start_time
                if elapsed > self.max_duration:
                    logger.warning(f"Max duration ({self.max_duration}s) reached")
                    # Don't stop here - let the main thread handle it
                    return
                
                with self._lock:
                    self._audio_buffer.append(indata.copy())
        
        try:
            self._stream = _sd.InputStream(
                samplerate=self.sample_rate,
                channels=self.channels,
                dtype=np.float32,
                device=self.device_index,
                callback=audio_callback,
            )
            self._stream.start()
            
            logger.info("Recording started")
            
        except Exception as e:
            logger.error(f"Failed to start recording: {e}")
            self._recording = False
            raise
    
    def _stop_recording(self) -> np.ndarray | None:
        """Stop recording and return captured audio.
        
        Returns:
            Audio data as numpy array, or None if not recording
        """
        if not self._recording:
            return None
        
        with self._lock:
            self._recording = False
        
        # Stop stream
        if self._stream:
            self._stream.stop()
            self._stream.close()
            self._stream = None
        
        # Concatenate audio buffer
        with self._lock:
            if not self._audio_buffer:
                return None
            
            audio = np.concatenate(self._audio_buffer, axis=0)
            self._audio_buffer.clear()
        
        # Flatten to mono if needed
        if audio.ndim > 1:
            audio = audio.mean(axis=1)
        
        return audio.astype(np.float32)
    
    @property
    def is_recording(self) -> bool:
        """Check if currently recording."""
        return self._recording
    
    @staticmethod
    def list_devices() -> list[dict[str, Any]]:
        """List available audio input devices."""
        try:
            _sd = _get_sounddevice()
            devices = _sd.query_devices()
            
            input_devices = []
            for i, dev in enumerate(devices):
                if dev["max_input_channels"] > 0:
                    input_devices.append({
                        "index": i,
                        "name": dev["name"],
                        "channels": dev["max_input_channels"],
                        "sample_rate": dev["default_samplerate"],
                    })
            
            return input_devices
            
        except Exception as e:
            logger.error(f"Failed to list audio devices: {e}")
            return []
    
    def shutdown(self) -> None:
        """Clean up resources."""
        self.stop()
        self.bus.unsubscribe(EventType.RECORD_START, self._on_record_start)
        self.bus.unsubscribe(EventType.RECORD_STOP, self._on_record_stop)
        self.bus.unsubscribe(EventType.SHUTDOWN_REQUESTED, self._on_shutdown)
        logger.info("AudioCapture shut down")
