"""
VoxPad Transcriber

Wraps faster-whisper for local speech-to-text transcription.

Usage:
    from voxpad.core.transcriber import Transcriber
    from voxpad.core.events import EventBus
    
    transcriber = Transcriber(EventBus(), config)
    # Transcriber automatically subscribes to AUDIO_READY events
"""

from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Any

import numpy as np

from voxpad.core.events import Event, EventBus, EventType

logger = logging.getLogger(__name__)

# Lazy import to avoid loading model at module import time
WhisperModel = None


def _get_whisper_model():
    """Lazy load WhisperModel to speed up startup."""
    global WhisperModel
    if WhisperModel is None:
        from faster_whisper import WhisperModel as _WhisperModel
        WhisperModel = _WhisperModel
    return WhisperModel


class Transcriber:
    """Handles audio transcription using faster-whisper.
    
    Subscribes to AUDIO_READY events and emits TRANSCRIPTION_COMPLETE
    or TRANSCRIPTION_ERROR events.
    
    Attributes:
        model: The loaded Whisper model (lazy-loaded on first use)
        config: Transcriber configuration
    """
    
    def __init__(self, bus: EventBus, config: dict[str, Any]) -> None:
        """Initialize the transcriber.
        
        Args:
            bus: EventBus for event communication
            config: Configuration dict with 'whisper' section
        """
        self.bus = bus
        self.config = config.get("whisper", {})
        self._model = None
        self._model_lock = False
        
        # Subscribe to audio events
        self.bus.subscribe(EventType.AUDIO_READY, self._on_audio_ready)
        
        logger.info(f"Transcriber initialized (model: {self.config.get('model', 'base.en')})")
    
    @property
    def model(self):
        """Lazy-load the Whisper model on first access."""
        if self._model is None:
            self._load_model()
        return self._model
    
    def _load_model(self) -> None:
        """Load the Whisper model based on config."""
        if self._model_lock:
            return
        
        self._model_lock = True
        
        model_name = self.config.get("model", "base.en")
        device = self.config.get("device", "auto")
        compute_type = self.config.get("compute_type", "int8")
        
        logger.info(f"Loading Whisper model: {model_name} (device={device}, compute={compute_type})")
        
        try:
            ModelClass = _get_whisper_model()
            
            # Handle 'auto' device selection
            if device == "auto":
                import torch
                device = "cuda" if torch.cuda.is_available() else "cpu"
            
            self._model = ModelClass(
                model_name,
                device=device,
                compute_type=compute_type,
            )
            
            logger.info(f"Model loaded successfully on {device}")
            
        except Exception as e:
            logger.error(f"Failed to load model: {e}")
            self._model_lock = False
            raise
    
    def _on_audio_ready(self, event: Event) -> None:
        """Handle AUDIO_READY events by transcribing the audio."""
        audio = event.data.get("audio")
        sample_rate = event.data.get("sample_rate", 16000)
        
        if audio is None:
            logger.warning("AUDIO_READY event with no audio data")
            return
        
        self.bus.emit(Event(type=EventType.TRANSCRIPTION_START))
        
        try:
            result = self.transcribe(audio, sample_rate)
            
            self.bus.emit(Event(
                type=EventType.TRANSCRIPTION_COMPLETE,
                data=result
            ))
            
        except Exception as e:
            logger.exception(f"Transcription failed: {e}")
            self.bus.emit(Event(
                type=EventType.TRANSCRIPTION_ERROR,
                data={"error": str(e)}
            ))
    
    def transcribe(
        self,
        audio: np.ndarray,
        sample_rate: int = 16000
    ) -> dict[str, Any]:
        """Transcribe audio data to text.
        
        Args:
            audio: Audio samples as numpy array (float32, mono)
            sample_rate: Sample rate of audio (should be 16000 for Whisper)
            
        Returns:
            Dict with keys: text, language, duration, segments
        """
        start_time = time.time()
        
        # Ensure correct format
        if audio.dtype != np.float32:
            audio = audio.astype(np.float32)
        
        # Normalize if needed
        if audio.max() > 1.0 or audio.min() < -1.0:
            audio = audio / max(abs(audio.max()), abs(audio.min()))
        
        # Resample if needed (Whisper expects 16kHz)
        if sample_rate != 16000:
            # Simple resampling - for production, use librosa or scipy
            ratio = 16000 / sample_rate
            new_length = int(len(audio) * ratio)
            indices = np.linspace(0, len(audio) - 1, new_length).astype(int)
            audio = audio[indices]
        
        # Transcribe
        language = self.config.get("language", "en")
        initial_prompt = self.config.get("initial_prompt")
        
        segments, info = self.model.transcribe(
            audio,
            language=language if language != "auto" else None,
            initial_prompt=initial_prompt,
            vad_filter=True,  # Filter out non-speech
        )
        
        # Collect results
        segments_list = list(segments)
        text = " ".join(seg.text.strip() for seg in segments_list)
        
        duration = time.time() - start_time
        audio_duration = len(audio) / 16000
        
        logger.info(
            f"Transcribed {audio_duration:.1f}s audio in {duration:.2f}s "
            f"({audio_duration/duration:.1f}x realtime)"
        )
        
        return {
            "text": text,
            "language": info.language,
            "duration": duration,
            "audio_duration": audio_duration,
            "segments": [
                {
                    "start": seg.start,
                    "end": seg.end,
                    "text": seg.text,
                }
                for seg in segments_list
            ],
        }
    
    def preload_model(self) -> None:
        """Preload the model (call during startup to avoid first-use delay)."""
        _ = self.model
    
    def shutdown(self) -> None:
        """Clean up resources."""
        self._model = None
        self.bus.unsubscribe(EventType.AUDIO_READY, self._on_audio_ready)
        logger.info("Transcriber shut down")
