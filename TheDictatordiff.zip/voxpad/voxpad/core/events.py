"""
VoxPad Event System

The event bus is the central nervous system of VoxPad. All modules communicate
through events, enabling loose coupling and parallel development.

Usage:
    from voxpad.core.events import EventBus, Event, EventType
    
    bus = EventBus()
    bus.subscribe(EventType.TRANSCRIPTION_COMPLETE, my_handler)
    bus.emit(Event(EventType.RECORD_START))
"""

from __future__ import annotations

import logging
import threading
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
from typing import Any, Callable
from uuid import uuid4

logger = logging.getLogger(__name__)


class EventType(Enum):
    """All event types in the system.
    
    Naming convention:
    - NOUN_VERB for state changes (RECORD_START)
    - NOUN_ADJECTIVE for completed states (TRANSCRIPTION_COMPLETE)
    """
    
    # === Input Events ===
    # Emitted by: input/midi.py, input/hotkeys.py
    RECORD_START = auto()
    """Recording has begun. Data: {}"""
    
    RECORD_STOP = auto()
    """Recording has stopped. Data: {}"""
    
    ACTION_TRIGGERED = auto()
    """A mapped action was triggered. Data: {"action": str, "source": str, "velocity": int}"""
    
    # === Audio Events ===
    # Emitted by: input/audio.py
    AUDIO_READY = auto()
    """Audio data is ready for processing. Data: {"audio": np.ndarray, "sample_rate": int, "duration": float}"""
    
    AUDIO_LEVEL = auto()
    """Current audio level (for VU meters). Data: {"level_db": float}"""
    
    # === Core Events ===
    # Emitted by: core/transcriber.py
    TRANSCRIPTION_START = auto()
    """Transcription processing has begun. Data: {}"""
    
    TRANSCRIPTION_COMPLETE = auto()
    """Transcription is complete. Data: {"text": str, "language": str, "duration": float}"""
    
    TRANSCRIPTION_ERROR = auto()
    """Transcription failed. Data: {"error": str}"""
    
    # Emitted by: core/session.py
    SESSION_STARTED = auto()
    """New session file created. Data: {"path": str}"""
    
    SESSION_UPDATED = auto()
    """Entry added to session. Data: {"entry_id": str, "text": str, "timestamp": str}"""
    
    SESSION_CLOSED = auto()
    """Session file closed. Data: {"path": str, "entry_count": int}"""
    
    # === Output Events ===
    # Emitted by: output/clipboard.py
    COPY_COMPLETE = auto()
    """Text copied to clipboard. Data: {"text": str}"""
    
    COPY_ERROR = auto()
    """Clipboard operation failed. Data: {"error": str}"""
    
    # Emitted by: output/gui.py
    USER_EDITED = auto()
    """User edited transcription in GUI. Data: {"original": str, "edited": str}"""
    
    # === Extension Events ===
    # Emitted by: extend/prompt_refiner.py
    REFINEMENT_REQUESTED = auto()
    """Request to refine transcription. Data: {"text": str}"""
    
    REFINEMENT_COMPLETE = auto()
    """Refinement complete. Data: {"original": str, "refined": str}"""
    
    REFINEMENT_ERROR = auto()
    """Refinement failed. Data: {"error": str}"""
    
    # Emitted by: extend/browser_launcher.py
    BROWSER_LAUNCH_REQUESTED = auto()
    """Request to open browser. Data: {"target": str, "text": str}"""
    
    BROWSER_LAUNCHED = auto()
    """Browser opened. Data: {"url": str}"""
    
    # === System Events ===
    SHUTDOWN_REQUESTED = auto()
    """Application shutdown requested. Data: {}"""
    
    ERROR = auto()
    """Generic error. Data: {"source": str, "error": str, "fatal": bool}"""


@dataclass
class Event:
    """An event that can be emitted and subscribed to.
    
    Attributes:
        type: The type of event
        data: Event-specific payload
        timestamp: When the event was created
        id: Unique identifier for this event instance
    """
    type: EventType
    data: dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)
    id: str = field(default_factory=lambda: str(uuid4())[:8])
    
    def __str__(self) -> str:
        return f"Event({self.type.name}, {self.data})"


# Type alias for event handlers
EventHandler = Callable[[Event], None]


class EventBus:
    """Central event bus for module communication.
    
    Thread-safe singleton that manages event subscriptions and emission.
    
    Usage:
        bus = EventBus()  # Always returns the same instance
        
        # Subscribe to events
        def on_transcription(event: Event):
            print(f"Got: {event.data['text']}")
        bus.subscribe(EventType.TRANSCRIPTION_COMPLETE, on_transcription)
        
        # Emit events
        bus.emit(Event(
            type=EventType.TRANSCRIPTION_COMPLETE,
            data={"text": "Hello world", "language": "en", "duration": 1.5}
        ))
        
        # Unsubscribe
        bus.unsubscribe(EventType.TRANSCRIPTION_COMPLETE, on_transcription)
    """
    
    _instance: EventBus | None = None
    _lock: threading.Lock = threading.Lock()
    
    def __new__(cls) -> EventBus:
        """Singleton pattern - returns existing instance or creates new one."""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    instance = super().__new__(cls)
                    instance._handlers = defaultdict(list)
                    instance._handler_lock = threading.Lock()
                    instance._history: list[Event] = []
                    instance._history_limit = 100
                    cls._instance = instance
        return cls._instance
    
    @classmethod
    def reset(cls) -> None:
        """Reset the singleton (primarily for testing)."""
        with cls._lock:
            cls._instance = None
    
    def subscribe(
        self, 
        event_type: EventType, 
        handler: EventHandler,
        priority: int = 0
    ) -> None:
        """Subscribe a handler to an event type.
        
        Args:
            event_type: The type of event to listen for
            handler: Callable that takes an Event and returns None
            priority: Higher priority handlers run first (default 0)
        """
        with self._handler_lock:
            self._handlers[event_type].append((priority, handler))
            # Sort by priority (descending)
            self._handlers[event_type].sort(key=lambda x: -x[0])
        
        logger.debug(f"Subscribed {handler.__name__} to {event_type.name}")
    
    def unsubscribe(self, event_type: EventType, handler: EventHandler) -> bool:
        """Unsubscribe a handler from an event type.
        
        Returns:
            True if handler was found and removed, False otherwise
        """
        with self._handler_lock:
            handlers = self._handlers[event_type]
            for i, (_, h) in enumerate(handlers):
                if h == handler:
                    handlers.pop(i)
                    logger.debug(f"Unsubscribed {handler.__name__} from {event_type.name}")
                    return True
        return False
    
    def emit(self, event: Event) -> None:
        """Emit an event to all subscribed handlers.
        
        Handlers are called synchronously in priority order.
        Exceptions in handlers are logged but don't stop other handlers.
        
        Args:
            event: The event to emit
        """
        logger.debug(f"Emitting {event}")
        
        # Add to history
        self._history.append(event)
        if len(self._history) > self._history_limit:
            self._history.pop(0)
        
        # Get handlers (copy to avoid lock during execution)
        with self._handler_lock:
            handlers = list(self._handlers[event.type])
        
        # Call handlers
        for _, handler in handlers:
            try:
                handler(event)
            except Exception as e:
                logger.exception(f"Handler {handler.__name__} raised exception: {e}")
    
    def emit_async(self, event: Event) -> threading.Thread:
        """Emit an event in a background thread.
        
        Returns:
            The thread running the emission
        """
        thread = threading.Thread(target=self.emit, args=(event,), daemon=True)
        thread.start()
        return thread
    
    def get_history(self, event_type: EventType | None = None) -> list[Event]:
        """Get recent event history.
        
        Args:
            event_type: Filter to specific type, or None for all
            
        Returns:
            List of recent events (newest last)
        """
        if event_type is None:
            return list(self._history)
        return [e for e in self._history if e.type == event_type]
    
    def clear_history(self) -> None:
        """Clear event history."""
        self._history.clear()
    
    def handler_count(self, event_type: EventType) -> int:
        """Get number of handlers for an event type."""
        with self._handler_lock:
            return len(self._handlers[event_type])


# Convenience function for quick access
def get_bus() -> EventBus:
    """Get the global EventBus instance."""
    return EventBus()
