"""
VoxPad Session Manager

Manages session state and persists transcriptions to markdown files.

Each session creates a timestamped .md file containing all transcriptions
from that session, making it easy to review or use for RAG later.

Usage:
    from voxpad.core.session import SessionManager
    from voxpad.core.events import EventBus
    
    session = SessionManager(EventBus(), config)
    # SessionManager automatically logs TRANSCRIPTION_COMPLETE events
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any
from uuid import uuid4

from voxpad.core.events import Event, EventBus, EventType

logger = logging.getLogger(__name__)


@dataclass
class SessionEntry:
    """A single transcription entry in a session."""
    id: str
    text: str
    timestamp: datetime
    language: str = "en"
    duration: float = 0.0
    edited: bool = False
    original_text: str | None = None
    
    def to_markdown(self, include_timestamp: bool = True) -> str:
        """Format entry as markdown."""
        lines = []
        
        if include_timestamp:
            time_str = self.timestamp.strftime("%H:%M:%S")
            lines.append(f"### [{time_str}]")
        
        lines.append("")
        lines.append(self.text)
        lines.append("")
        
        if self.edited and self.original_text:
            lines.append(f"> *Original: {self.original_text}*")
            lines.append("")
        
        return "\n".join(lines)


@dataclass
class Session:
    """A recording session containing multiple entries."""
    id: str = field(default_factory=lambda: str(uuid4())[:8])
    started_at: datetime = field(default_factory=datetime.now)
    entries: list[SessionEntry] = field(default_factory=list)
    file_path: Path | None = None
    
    def add_entry(self, text: str, **kwargs) -> SessionEntry:
        """Add a new entry to the session."""
        entry = SessionEntry(
            id=str(uuid4())[:8],
            text=text,
            timestamp=datetime.now(),
            **kwargs
        )
        self.entries.append(entry)
        return entry
    
    def get_entry(self, entry_id: str) -> SessionEntry | None:
        """Get an entry by ID."""
        for entry in self.entries:
            if entry.id == entry_id:
                return entry
        return None
    
    def remove_entry(self, entry_id: str) -> bool:
        """Remove an entry by ID."""
        for i, entry in enumerate(self.entries):
            if entry.id == entry_id:
                self.entries.pop(i)
                return True
        return False
    
    def to_markdown(self, include_timestamps: bool = True) -> str:
        """Format entire session as markdown."""
        lines = [
            f"# VoxPad Session",
            f"",
            f"**Date:** {self.started_at.strftime('%Y-%m-%d')}",
            f"**Started:** {self.started_at.strftime('%H:%M:%S')}",
            f"**Entries:** {len(self.entries)}",
            f"",
            f"---",
            f"",
        ]
        
        for entry in self.entries:
            lines.append(entry.to_markdown(include_timestamps))
        
        return "\n".join(lines)
    
    @property
    def last_entry(self) -> SessionEntry | None:
        """Get the most recent entry."""
        return self.entries[-1] if self.entries else None
    
    @property
    def all_text(self) -> str:
        """Get all transcription text concatenated."""
        return "\n\n".join(entry.text for entry in self.entries)


class SessionManager:
    """Manages session state and file persistence.
    
    Subscribes to TRANSCRIPTION_COMPLETE events and logs them to session files.
    Emits SESSION_STARTED, SESSION_UPDATED, and SESSION_CLOSED events.
    """
    
    def __init__(self, bus: EventBus, config: dict[str, Any]) -> None:
        """Initialize the session manager.
        
        Args:
            bus: EventBus for event communication
            config: Configuration dict with 'session' section
        """
        self.bus = bus
        self.config = config.get("session", {})
        self.current_session: Session | None = None
        
        # Setup output directory
        output_dir = self.config.get("output_dir", "~/.voxpad/sessions")
        self.output_dir = Path(output_dir).expanduser()
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # Subscribe to events
        self.bus.subscribe(EventType.TRANSCRIPTION_COMPLETE, self._on_transcription)
        self.bus.subscribe(EventType.USER_EDITED, self._on_user_edited)
        self.bus.subscribe(EventType.SHUTDOWN_REQUESTED, self._on_shutdown)
        
        # Start a new session
        self._start_session()
        
        logger.info(f"SessionManager initialized (output: {self.output_dir})")
    
    def _start_session(self) -> None:
        """Start a new session."""
        self.current_session = Session()
        
        # Generate filename
        filename_format = self.config.get("filename_format", "{date}_{time}.md")
        now = self.current_session.started_at
        filename = filename_format.format(
            date=now.strftime("%Y-%m-%d"),
            time=now.strftime("%H%M%S"),
            timestamp=now.strftime("%Y%m%d_%H%M%S"),
        )
        
        self.current_session.file_path = self.output_dir / filename
        
        # Write initial header
        self._write_session_file()
        
        self.bus.emit(Event(
            type=EventType.SESSION_STARTED,
            data={"path": str(self.current_session.file_path)}
        ))
        
        logger.info(f"Started session: {self.current_session.file_path}")
    
    def _on_transcription(self, event: Event) -> None:
        """Handle transcription complete events."""
        if self.current_session is None:
            self._start_session()
        
        text = event.data.get("text", "")
        if not text.strip():
            logger.debug("Ignoring empty transcription")
            return
        
        entry = self.current_session.add_entry(
            text=text,
            language=event.data.get("language", "en"),
            duration=event.data.get("duration", 0.0),
        )
        
        # Write to file
        self._write_session_file()
        
        # Check if we need to rotate
        max_entries = self.config.get("max_entries_per_file", 100)
        if len(self.current_session.entries) >= max_entries:
            self._close_session()
            self._start_session()
        
        self.bus.emit(Event(
            type=EventType.SESSION_UPDATED,
            data={
                "entry_id": entry.id,
                "text": entry.text,
                "timestamp": entry.timestamp.isoformat(),
            }
        ))
    
    def _on_user_edited(self, event: Event) -> None:
        """Handle user edit events."""
        if self.current_session is None:
            return
        
        # Find and update the last entry (or specific entry if ID provided)
        entry = self.current_session.last_entry
        if entry is None:
            return
        
        original = event.data.get("original", entry.text)
        edited = event.data.get("edited", "")
        
        entry.original_text = original
        entry.text = edited
        entry.edited = True
        
        self._write_session_file()
        
        logger.debug(f"Entry {entry.id} edited")
    
    def _on_shutdown(self, event: Event) -> None:
        """Handle shutdown events."""
        self._close_session()
    
    def _write_session_file(self) -> None:
        """Write current session to file."""
        if self.current_session is None or self.current_session.file_path is None:
            return
        
        include_timestamps = self.config.get("include_timestamps", True)
        content = self.current_session.to_markdown(include_timestamps)
        
        self.current_session.file_path.write_text(content, encoding="utf-8")
    
    def _close_session(self) -> None:
        """Close the current session."""
        if self.current_session is None:
            return
        
        self._write_session_file()
        
        self.bus.emit(Event(
            type=EventType.SESSION_CLOSED,
            data={
                "path": str(self.current_session.file_path),
                "entry_count": len(self.current_session.entries),
            }
        ))
        
        logger.info(
            f"Closed session: {self.current_session.file_path} "
            f"({len(self.current_session.entries)} entries)"
        )
        
        self.current_session = None
    
    def get_last_text(self) -> str | None:
        """Get the text of the last transcription."""
        if self.current_session and self.current_session.last_entry:
            return self.current_session.last_entry.text
        return None
    
    def get_all_text(self) -> str:
        """Get all text from current session."""
        if self.current_session:
            return self.current_session.all_text
        return ""
    
    def undo_last(self) -> bool:
        """Remove the last entry from the session."""
        if self.current_session and self.current_session.entries:
            entry = self.current_session.entries.pop()
            self._write_session_file()
            logger.info(f"Removed entry {entry.id}")
            return True
        return False
    
    def clear_current(self) -> None:
        """Clear all entries from current session (but keep file)."""
        if self.current_session:
            self.current_session.entries.clear()
            self._write_session_file()
            logger.info("Cleared current session")
    
    def shutdown(self) -> None:
        """Clean up resources."""
        self._close_session()
        self.bus.unsubscribe(EventType.TRANSCRIPTION_COMPLETE, self._on_transcription)
        self.bus.unsubscribe(EventType.USER_EDITED, self._on_user_edited)
        self.bus.unsubscribe(EventType.SHUTDOWN_REQUESTED, self._on_shutdown)
        logger.info("SessionManager shut down")
