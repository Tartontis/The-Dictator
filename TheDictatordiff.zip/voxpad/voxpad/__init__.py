"""
VoxPad - Local voice dictation with MIDI control

A privacy-first, extensible dictation application that runs locally
using Faster-Whisper for transcription.

Quick Start:
    from voxpad.app import VoxPadApp
    
    app = VoxPadApp()
    app.run()

Or from command line:
    voxpad
    voxpad --list-midi
    voxpad --list-audio
"""

__version__ = "0.1.0"
__author__ = "Tartontis"

from voxpad.app import VoxPadApp
from voxpad.core.events import Event, EventBus, EventType

__all__ = [
    "VoxPadApp",
    "EventBus",
    "Event",
    "EventType",
]
