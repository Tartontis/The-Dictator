# VoxPad Architecture

## Design Philosophy

1. **Event-driven** — All modules communicate through an event bus, not direct imports
2. **Config over code** — Behavior changes via YAML, not source edits
3. **Extension-first** — Core is minimal; features live in extensions
4. **Session-aware** — Every interaction is logged for later retrieval/RAG

## System Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                         Event Bus                               │
│            (voxpad/core/events.py - the spine)                  │
└─────────────────────────────────────────────────────────────────┘
         ↑                    ↑                    ↑
    ┌────┴────┐          ┌────┴────┐          ┌────┴────┐
    │  Input  │          │  Core   │          │ Output  │
    │  Layer  │          │ Engine  │          │  Layer  │
    └─────────┘          └─────────┘          └─────────┘
    midi.py               transcriber.py       clipboard.py
    hotkeys.py            session.py           gui.py
    audio.py                                   notifications.py
                              │
                              ↓
                      ┌───────────────┐
                      │   Extensions  │
                      │   (extend/)   │
                      └───────────────┘
                      prompt_refiner.py
                      browser_launcher.py
```

## Module Responsibilities

### Input Layer (`voxpad/input/`)

**Purpose:** Capture user intent from physical devices

| Module | Responsibility |
|--------|----------------|
| `base.py` | Abstract `InputHandler` protocol |
| `midi.py` | Listen for MIDI note-on events, map to actions |
| `hotkeys.py` | Keyboard shortcut fallback (no MIDI device) |
| `audio.py` | Microphone capture via sounddevice |

**Emits:** `RECORD_START`, `RECORD_STOP`, `ACTION_TRIGGERED`

### Core Engine (`voxpad/core/`)

**Purpose:** Process audio, manage state, coordinate flow

| Module | Responsibility |
|--------|----------------|
| `events.py` | Event definitions, EventBus singleton |
| `transcriber.py` | Faster-Whisper wrapper, model management |
| `session.py` | Session state, .md file logging |

**Emits:** `TRANSCRIPTION_COMPLETE`, `SESSION_UPDATED`

### Output Layer (`voxpad/output/`)

**Purpose:** Deliver results to user

| Module | Responsibility |
|--------|----------------|
| `clipboard.py` | Platform-agnostic clipboard (wl-copy, xclip, etc.) |
| `gui.py` | Optional TUI/GUI for editing, status |
| `notifications.py` | Desktop notifications |

**Emits:** `COPY_COMPLETE`, `USER_EDITED`

### Extensions (`voxpad/extend/`)

**Purpose:** Optional features that enhance base functionality

| Module | Responsibility |
|--------|----------------|
| `base.py` | `Extension` protocol definition |
| `prompt_refiner.py` | Call API to transform dictation → polished prompt |
| `browser_launcher.py` | Open browser to LLM with pre-filled context |

**Pattern:** Extensions subscribe to events and optionally emit new ones.

## Event Types

```python
class EventType(Enum):
    # Input events
    RECORD_START = auto()
    RECORD_STOP = auto()
    ACTION_TRIGGERED = auto()
    
    # Core events  
    AUDIO_READY = auto()
    TRANSCRIPTION_COMPLETE = auto()
    SESSION_UPDATED = auto()
    
    # Output events
    COPY_COMPLETE = auto()
    USER_EDITED = auto()
    
    # Extension events
    REFINEMENT_REQUESTED = auto()
    REFINEMENT_COMPLETE = auto()
    BROWSER_LAUNCH_REQUESTED = auto()
```

## Data Flow: Basic Dictation

```
1. User presses MIDI pad 36
2. midi.py emits RECORD_START
3. audio.py begins capturing
4. User presses pad 36 again
5. midi.py emits RECORD_STOP
6. audio.py emits AUDIO_READY with audio data
7. transcriber.py processes, emits TRANSCRIPTION_COMPLETE
8. session.py logs to .md, emits SESSION_UPDATED
9. clipboard.py copies text, emits COPY_COMPLETE
10. notifications.py shows "Copied: {preview}"
```

## Configuration Schema

### `config/default.yaml`

```yaml
whisper:
  model: "base.en"           # tiny, base, small, medium, large-v3
  device: "auto"             # auto, cpu, cuda
  compute_type: "int8"       # float16, int8, int8_float16

audio:
  sample_rate: 16000
  channels: 1
  
session:
  output_dir: "~/.voxpad/sessions"
  filename_format: "{date}_{time}.md"
  
clipboard:
  auto_copy: true
  
gui:
  enabled: false             # TUI off by default
  
extensions:
  enabled:
    - prompt_refiner
    - browser_launcher
```

### `config/midi_mappings.yaml`

```yaml
# Find your pad numbers with: python scripts/test_midi_device.py
device_name: null            # null = auto-detect first device

mappings:
  # note_number: action_name
  36: record_toggle
  37: copy_to_clipboard
  38: clear_current
  39: refine_prompt          # requires prompt_refiner extension
  40: new_chat_claude        # requires browser_launcher extension
  41: new_chat_chatgpt
  
# Bank switching (if your pad has multiple banks)
banks:
  enabled: false
  switch_note: 48
```

## Extension Protocol

Extensions implement this interface:

```python
from typing import Protocol
from voxpad.core.events import Event, EventBus

class Extension(Protocol):
    name: str
    
    def initialize(self, bus: EventBus, config: dict) -> None:
        """Called on startup. Subscribe to events here."""
        ...
    
    def shutdown(self) -> None:
        """Called on exit. Cleanup here."""
        ...
```

## File Locations

| Path | Purpose |
|------|---------|
| `~/.voxpad/config/` | User config overrides |
| `~/.voxpad/sessions/` | Session .md files |
| `~/.voxpad/models/` | Downloaded Whisper models |
| `~/.voxpad/logs/` | Application logs |

## Platform Notes

### Chromebook (Crostini)

- Audio input requires Linux settings → "Allow Linux to access your microphone"
- MIDI works via ALSA in the container
- Clipboard uses `wl-copy` (Wayland)

### Standard Linux

- MIDI via ALSA or JACK (auto-detected by python-rtmidi)
- Clipboard uses `xclip` (X11) or `wl-copy` (Wayland)

## Testing Strategy

- Unit tests for each module in isolation
- Integration tests use mock EventBus
- E2E tests require actual audio device (marked `@pytest.mark.hardware`)
